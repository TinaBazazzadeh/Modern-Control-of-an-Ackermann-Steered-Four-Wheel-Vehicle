# Mathematical Model and Assumptions

## State-space representation

The core four-state representation is

\[
x = \begin{bmatrix}v_x & v_y & \theta & r\end{bmatrix}^{T},
\]

where \(v_x\) and \(v_y\) denote longitudinal and lateral velocity in the vehicle body frame, \(\theta\) is heading angle, and \(r\) is yaw rate. The simplified model uses steering angle \(\delta\) as its principal input.

The lateral tire forces are approximated using a linear cornering-stiffness model:

\[
\alpha_f = \delta - \tan^{-1}\left(\frac{v_y+L_f r}{v_x}\right),
\qquad
\alpha_r = -\tan^{-1}\left(\frac{v_y-L_r r}{v_x}\right),
\]

\[
F_{yf}=C_f\alpha_f,\qquad F_{yr}=C_r\alpha_r.
\]

A representative nonlinear dynamics model used in the coursework is

\[
\dot v_x = v_y r,
\]

\[
\dot v_y = -v_xr + \frac{F_{yf}+F_{yr}}{m},
\]

\[
\dot\theta = r,
\]

\[
\dot r = \frac{L_fF_{yf}-L_rF_{yr}}{I_z}.
\]

Here \(m\) is vehicle mass, \(I_z\) is yaw moment of inertia, \(L_f\) and \(L_r\) are distances from the center of gravity to the front and rear axles, and \(C_f\) and \(C_r\) are front and rear cornering stiffnesses.

## Linearization

The linear model is obtained by evaluating the Jacobians of the nonlinear dynamics with respect to the state and input around a selected operating point:

\[
A=\left.\frac{\partial f}{\partial x}\right|_{x_0,u_0},
\qquad
B=\left.\frac{\partial f}{\partial u}\right|_{x_0,u_0}.
\]

For output \(y=Cx+Du\), the matrices \(C\) and \(D\) specify the measured outputs and direct feedthrough. The supplied scripts use more than one linear model across coursework phases. Their matrices and parameter sets should therefore be treated as phase-specific rather than interchangeable.

## Modeling assumptions and limits

- The tire model is linear in tire slip angle.
- The linearized model is local to its selected operating point.
- Tire saturation, complex tire dynamics, road variation, and other high-fidelity effects are not fully represented.
- State estimation quality depends on model accuracy, sensor-noise assumptions, and filter tuning.
- Linear stability around an operating point does not establish global stability of the nonlinear vehicle model.

The equations are intended for simulation and coursework analysis, not for direct use in a real vehicle without validation and safety engineering.
