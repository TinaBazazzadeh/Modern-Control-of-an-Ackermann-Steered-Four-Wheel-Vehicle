# Phase 2 Script Guide

## `pole_placement_linear_tracking.m`
Builds a state-feedback gain using a Sylvester-equation pole-placement construction, calculates a static prefilter, and simulates step and sinusoidal tracking on the linear model.

## `pole_placement_nonlinear_simulation.m`
Uses a controller designed from the linear state-space model inside a nonlinear vehicle simulation. It includes reference tracking and disturbance/noise scenarios.

## `lqr_linear_nonlinear_comparison.m`
Computes an LQR gain using the specified state and input weighting matrices, then applies the controller to linear and nonlinear models.

## Notes before execution
- Each script clears the MATLAB workspace and closes existing figures.
- The scripts use the Control System Toolbox.
- The nonlinear scripts define local helper functions at the end of the script, so run them in a MATLAB release that supports local functions in scripts.
- The controller output dimension and reference dimension must match the model used by the script.
- Inspect the generated plots and check the numerical conditioning of matrix calculations before relying on the results.
