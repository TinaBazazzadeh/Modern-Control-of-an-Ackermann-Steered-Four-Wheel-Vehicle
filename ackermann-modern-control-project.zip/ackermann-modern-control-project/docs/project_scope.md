# Project Scope

## Objective

Analyze an Ackermann-steered ground vehicle using modern control methods, from nonlinear modeling and local linearization through feedback control and state estimation.

## Engineering questions

1. What does the local linear model reveal about the vehicle's modes and stability?
2. Which states are controllable and observable under the selected input/output configuration?
3. How do state-feedback and observer designs affect the closed-loop response?
4. How does an estimator behave when measurements are noisy or model parameters are uncertain?
5. Where does a controller designed from a linear model fail when applied to nonlinear dynamics?

## Work packages

| Work package | Methods | Main output |
|---|---|---|
| Modeling and analysis | Nonlinear equations, Jacobians, eigenvalues, transfer functions | Linear state-space model and structural analysis |
| Stability and system properties | Internal/BIBO stability checks, controllability and observability | Assessment of modes and system properties |
| Feedback control | Pole placement, Sylvester equation, static prefilter, Linear Quadratic Regulator (LQR) | State-feedback gains and closed-loop model |
| State observation | Observable decomposition, full/reduced observer approaches | State estimates and observer error dynamics |
| Robustness and estimation | Parameter variation, disturbances, measurement noise, EKF | Comparison of nominal and perturbed simulations |

## Evaluation approach

The coursework evaluates time-domain behavior and closed-loop poles, and compares linear and nonlinear simulations. Results should be assessed using tracking error, settling behavior, peak response, estimation error, and whether all state trajectories remain bounded. Where these metrics are not calculated by the current scripts, they should be added before making quantitative performance claims.

## Additional Phase 2 work

Phase 2 adds a linear pole-placement tracking script, a nonlinear simulation using the designed linear controller, and an LQR comparison script. The LQR design minimizes a quadratic cost of the form

\[
J=\int_0^\infty (x^TQx+u^TRu)\,dt,
\]

subject to the linear state-space model. The matrices \(Q\) and \(R\) express the relative penalties assigned to state deviation and control effort. The supplied script also applies the resulting controller to a nonlinear model, allowing a comparison between design-model behavior and nonlinear simulation behavior.
