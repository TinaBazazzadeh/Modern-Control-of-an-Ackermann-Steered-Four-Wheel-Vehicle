# Before Publishing

- [ ] Replace the Team 7 placeholder in `CITATION.cff` with the repository owner's preferred attribution.
- [ ] Add a short contributor statement to `README.md` describing your own work and the team-work context.
- [ ] Confirm you have permission to publish the original coursework code and any included material.
- [ ] Run each MATLAB script in a clean workspace and fix any errors.
- [ ] Check that the required MATLAB toolboxes are available.
- [ ] Generate and commit selected figures from reproducible runs.
- [ ] Add computed performance metrics instead of relying only on qualitative descriptions.
- [ ] Verify every reference and DOI.
- [ ] Remove personal information that should not be public.
