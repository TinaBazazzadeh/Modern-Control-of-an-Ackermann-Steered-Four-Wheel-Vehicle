# References

## Coursework and model background

1. Team 7, *Modern Control Project: Ackermann-Steered Four-Wheel Ground Vehicle*, course project report, Fall 2025. The supplied coursework report covers vehicle modeling, linearization, state-space analysis, stability, controllability/observability, feedback control, observer design, uncertainty analysis, and Kalman filtering.
2. Franch, J., and Rodríguez-Fortun, J.-M. (2009). “Control and Trajectory Generation of an Ackerman Vehicle by Dynamic Linearization.” European Control Conference. DOI: 10.23919/ECC.2009.7075182.
3. Xu, L., Zhuang, W., Yin, G., Li, G., and Bian, C. (2019). “Robust overtaking control of autonomous electric vehicle with parameter uncertainties.” *Proceedings of the Institution of Mechanical Engineers, Part D: Journal of Automobile Engineering*. DOI: 10.1177/0954407018824522.

## State estimation background

4. Doumiati, M., Charara, A., Victorino, A., Lechner, D., and Dubuisson, B. (Eds.). (2012). *Vehicle Dynamics Estimation using Kalman Filtering: Experimental Validation*. Wiley.
5. Jin, X., et al. (2019). “Advanced Estimation Techniques for Vehicle System Dynamics: A Review.” *Sensors*, 19(19), 4289.

The original coursework report also listed additional Kalman-filter references. Bibliographic details should be verified against the publisher record before formal academic submission.
