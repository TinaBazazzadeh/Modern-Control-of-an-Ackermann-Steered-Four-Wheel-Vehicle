# Modern Control of an Ackermann-Steered Ground Vehicle

## Abstract

This project studies modeling, feedback control, state observation, and state estimation for an Ackermann-steered ground vehicle. A nonlinear lateral-dynamics model is formulated and linearized around an operating point. The resulting state-space models are examined through eigenvalue analysis, transfer functions, controllability, and observability. State-feedback control is then combined with full-order or reduced-order observer designs. Later coursework phases consider parameter uncertainty, disturbances, measurement noise, and Kalman-filter-based estimation.

The submitted simulations indicate a clear distinction between nominal linear behavior and nonlinear closed-loop behavior. Several nominal linear cases show stable or acceptable tracking, while the reported nonlinear simulations diverge under demanding references and disturbances. These outcomes demonstrate the limitations of applying a local linear controller outside the region where its model is a good approximation.

## 1. Introduction

Vehicle lateral dynamics involve coupled motion in longitudinal velocity, lateral velocity, heading, and yaw rate. Ackermann steering geometry supports turning by assigning different steering angles to the inner and outer front wheels. For control design, the vehicle can be approximated by a nonlinear dynamic model and analyzed locally using linear systems theory.

The purpose of this project is to apply modern-control concepts to the vehicle model and examine both their strengths and their limits. The work progresses from model development and system analysis to feedback design, observer implementation, and state estimation under uncertainty.

## 2. Model formulation

The state vector is defined as

\[
x=[v_x,\;v_y,\;\theta,\;r]^T,
\]

where \(v_x\) and \(v_y\) are body-frame longitudinal and lateral velocities, \(\theta\) is heading angle, and \(r\) is yaw rate. The nonlinear model uses front and rear tire slip angles to estimate lateral tire forces. In the simplified model,

\[
F_{yf}=C_f\alpha_f,\qquad F_{yr}=C_r\alpha_r,
\]

with

\[
\alpha_f=\delta-\tan^{-1}\left(\frac{v_y+L_fr}{v_x}\right),
\qquad
\alpha_r=-\tan^{-1}\left(\frac{v_y-L_rr}{v_x}\right).
\]

The state derivatives follow the force and moment balances described in `docs/mathematical_model.md`. A local linear model is obtained by evaluating the Jacobian matrices \(A\) and \(B\) at the selected operating point. The coursework contains phase-specific model matrices and parameter values; results from different phases should not be compared unless their operating points and assumptions match.

## 3. Linear system analysis

The initial analysis examines the state matrix eigenvalues, transfer functions, state responses, and stability properties. Controllability and observability are evaluated using the corresponding controllability and observability matrices.

These tests answer different questions. Controllability determines whether the input can move the state through the model's state space, while observability determines whether the internal state can be reconstructed from the measured outputs. An unobservable mode cannot be reconstructed by an observer using the specified output configuration, even if the other states are observable.

The scripts also use Lyapunov-equation calculations and time-domain response plots. Such calculations must be interpreted in light of the system's eigenstructure. In particular, a model with a pole at the origin does not satisfy asymptotic stability of the full state, and the standard continuous-time Lyapunov equation with positive-definite \(Q\) requires a Hurwitz matrix for a positive-definite solution.

## 4. State-feedback control

The controller scripts use pole-placement ideas, including a Sylvester-equation construction, to obtain state-feedback gains. In the standard state-feedback form,

\[
u=-Kx+Nr,
\]

\(K\) shapes the closed-loop dynamics and \(N\) is a reference prefilter intended to improve steady-state tracking. The closed-loop state matrix is \(A_{cl}=A-BK\).

The controller design is based on a linear model. Its performance depends on the chosen poles, the input matrix, actuator constraints, and the accuracy of the model around the operating point. Static prefiltering can improve steady-state reference scaling, but it does not by itself guarantee good transient tracking or robustness to nonlinear effects.

## 5. Pole placement and LQR control

The second phase extends the feedback study with a pole-placement tracking implementation and a Linear Quadratic Regulator (LQR). Pole placement assigns the closed-loop eigenvalues through a chosen feedback structure, while LQR selects a gain that minimizes a quadratic objective,

\[
J=\int_0^\infty (x^TQx+u^TRu)\,dt.
\]

The state weighting matrix \(Q\) penalizes state deviations, and the input weighting matrix \(R\) penalizes control effort. The phase includes both linear tracking simulations and a nonlinear vehicle simulation using a controller designed from the linear model. The comparison is useful for identifying the effect of model mismatch. The controller's performance should be judged from the generated trajectories and computed tracking metrics, rather than from the controller design method alone.

## 6. State observers

The observer-design phase examines full-order and reduced-order approaches. The model's observable decomposition is used to identify the subsystem whose states can be reconstructed from the available outputs. Observer gains are selected by pole placement on the observable subsystem.

Observer poles are typically selected faster than the dominant controller poles so that estimation error decays promptly. Making the observer arbitrarily fast is not always beneficial: fast poles can amplify measurement noise and increase sensitivity to model mismatch. A reduced-order observer can lower computational effort, but its structure must be consistent with the observable and directly measured state components.

## 7. Uncertainty and nonlinear simulation

Later phases investigate how the nominal controller and observer behave when the model is perturbed or when the simulation includes disturbances and measurement noise. The supplied Phase 3 report describes acceptable behavior in several nominal linear scenarios, including responses to constant disturbance and measurement noise. It also reports large, unbounded-looking state excursions in several nonlinear scenarios under sinusoidal references, constant disturbances, sinusoidal disturbances, and noise.

These are qualitative findings from the coursework report, not independently regenerated benchmark values. The numerical trajectories should be reproduced in MATLAB before quoting exact peak values or settling times. Any apparent divergence should also be checked for numerical integration step size, input saturation, state constraints, sign conventions, and consistency between the controller's model and the nonlinear plant.

## 8. Kalman-filter-based estimation

The final phase introduces Kalman filtering for noisy measurements and nonlinear state estimation. The Extended Kalman Filter (EKF) propagates a state estimate through the nonlinear model and uses a local Jacobian approximation to update the estimate from measurements. Its performance depends on the process-noise covariance \(Q\), measurement-noise covariance \(R\), initialization, and the quality of the plant model.

An EKF estimates state; it does not directly correct a poorly designed feedback law. If the feedback controller uses an inaccurate model or is applied far outside the linearization region, a better state estimate alone cannot guarantee closed-loop stability. Estimator and controller design must therefore be evaluated as a coupled system.

## 9. Main findings

1. Linearization enables standard tools such as eigenvalue analysis, pole placement, and observer design to be applied to the vehicle model.
2. Controllability and observability must be checked before choosing controller and observer structures.
3. Feedback and observer designs should be evaluated using both state estimates and closed-loop trajectories.
4. The submitted simulations show a marked performance gap between the linear model and the nonlinear plant under challenging conditions.
5. The EKF can reduce the effect of measurement noise when its assumptions are reasonable, but it cannot compensate for severe plant-model mismatch or an unsuitable control law.

## 10. Limitations

The model uses simplified tire-force relationships and local linearization. The coursework scripts use different parameter sets and state-space matrices across phases. The supplied nonlinear results include severe divergence in some scenarios, but the current report does not provide a uniform set of computed performance metrics across every test. In addition, actuator saturation and explicit safety constraints are not consistently integrated into all scripts.

The project is a simulation study. It does not establish real-vehicle safety or performance, and no code should be deployed on a physical vehicle without model validation, hardware-in-the-loop testing, actuator limits, fault handling, and an appropriate safety process.

## 11. Future work

- Consolidate the model parameters and units into a single configuration file.
- Add automated tests for matrix dimensions, controllability, observability, and closed-loop poles.
- Calculate common performance metrics for every test: RMS tracking error, peak error, settling time, and estimation RMSE.
- Add actuator saturation and anti-windup or constrained-control logic where appropriate.
- Compare linear state feedback with gain scheduling, nonlinear feedback linearization, or model predictive control.
- Validate the nonlinear model against reference data before drawing conclusions about real vehicle behavior.
- Make simulations reproducible by fixing random seeds and saving generated figures and metrics.

## References

The project was informed by the coursework materials and the references listed in `references/references.md`. The repository's source scripts are organized under `src/`.
