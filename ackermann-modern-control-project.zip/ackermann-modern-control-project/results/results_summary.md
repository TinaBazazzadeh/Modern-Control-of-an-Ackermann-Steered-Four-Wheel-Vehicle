# Simulation Results Summary

This summary records the qualitative conclusions described in the submitted coursework report. It does not claim that all simulations have been rerun independently from the packaged repository.

| Scenario described in coursework | Linear-model behavior reported | Nonlinear-model behavior reported |
|---|---|---|
| Nominal/reference tracking | Generally acceptable in selected nominal tests | Strong divergence reported in several tests |
| Sinusoidal reference | Poor tracking in the report's example; large tracking mismatch | Large excursions and unstable-looking response reported |
| Constant disturbance | Settling near the reference with small residual error in the reported case | Large excursions and unstable-looking response reported |
| Sinusoidal disturbance | Oscillatory response with some tracking error | Rapid divergence reported |
| Measurement noise | Small fluctuations around the target in the reported case | Large excursions reported |

## Engineering interpretation

The principal finding is model mismatch. A controller designed from a local linear approximation can work near its design point but may fail when nonlinear effects, disturbances, or large reference changes dominate. An EKF may improve state estimates in the presence of measurement noise, but state estimation does not replace a suitable feedback design.

## Before publishing numerical claims

Rerun the MATLAB scripts and record, for each test:

- Maximum absolute tracking error
- RMS tracking error
- Settling time and overshoot, where applicable
- Estimation RMSE
- Whether any state or input exceeded its defined physical limits
- MATLAB release and toolbox versions

The qualitative entries above should be replaced or supplemented with reproducible plots and computed metrics after validation.

## Phase 2 scripts

- `pole_placement_linear_tracking.m` evaluates the pole-placement design on the linear model with static reference prefiltering.
- `pole_placement_nonlinear_simulation.m` applies the linear controller to the nonlinear vehicle dynamics under several test scenarios.
- `lqr_linear_nonlinear_comparison.m` implements an LQR controller and compares its behavior on linear and nonlinear models.

These scripts define the test cases and generate figures. Numerical performance values should be calculated from a fresh MATLAB run before being stated as verified results.
