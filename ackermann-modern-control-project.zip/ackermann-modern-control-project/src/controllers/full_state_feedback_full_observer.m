clc;
clear;
close all;

A = [-0.0022,0,0,0;
      0,-13.8828,0,-1.1393;
      0,0,0,1;
      0,1.5933,0,-13.1524];

B = [0,0.0006,0.0006,0.0006,0.0006;
     30.5862,0,0,0,0;
     0,0,0,0,0;
     17.6719,-0.0002,-0.0002,0.0002,0.0002];

C = [1,0,0,0;
     0,1,0,0;
     0,0,0,1];

D = zeros(3,5);

F = [-15,-1,0,0;
      1,-15,0,0;
      0,0,-20,0;
      0,0,0,-10];

nx = size(A,1); ny = size(C,1); nu = size(B,2);

Kbar = [1 0 0 0;
        0 1 0 0;
        0 0 1 0;
        0 0 0 1;
        1 2 3 4];

obsv(F,Kbar);
rank(obsv(F,Kbar));

RHS = B * Kbar;
P = sylvester(A, -F, RHS);

disp('Pole placement poles:');
disp(P);

K = Kbar / P;

Acl = A - B*K;
sys_cl = ss(Acl, B, C, D);

disp('Closed loop poles:');
disp(eig(Acl));

% figure;
% step(sys_cl);
% grid on;

%% PreFilter
sys = ss(Acl, B, C, D);

% Minimal realization to remove the unobservable integrator mode
sys_min = minreal(sys, 1e-8);

% DC gain from minimal realization
G0 = dcgain(sys_min);
if any(~isfinite(G0), 'all')
    eps0 = 1e-3;
    G0 = -C * ((Acl - eps0*eye(nx)) \ B);
end

disp('DC gain matrix G0:');
disp(G0);

N = pinv(G0);

sys_r = ss(Acl, B*N, C, zeros(3,3));

% figure;
% step(sys_r);
% title('Pole Placement & Static Prefilter');
% grid on;

%% state feedback(order 4) & FullOrder Observer
O = obsv(A,C);
disp('rank(obsv(A,C)) = ');
disp(rank(O));

[Abar,Bbar,Cbar,T,k] = obsvf(A,B,C);

no  = sum(k);        % observable states count
nuo = nx - no;       % unobservable states count

Ao = Abar(nuo+1:end, nuo+1:end);
Bo = Bbar(nuo+1:end, :);
Co = Cbar(:,  nuo+1:end);

observer_poles = -30 * ones(1, no);
Lo = place(Ao', Co', observer_poles)';

Lbar = [zeros(nuo, ny); Lo];

Tinv = T \ eye(nx);

Khat = K * Tinv;

A11 = A;
A12 = -B*Khat;

A21 = Lbar*C;
A22 = Abar - Bbar*Khat - Lbar*Cbar;

B1  = B*N;
B2  = Bbar*N;

A_aug = [A11 A12;
         A21 A22];

B_aug = [B1;
         B2];

C_aug = [C zeros(ny,nx)];
D_aug = zeros(ny, size(N,2));

sys_ce = ss(A_aug, B_aug, C_aug, D_aug);

disp('Closed loop poles (state feedback(order 4) & FullOrder Observer):');
disp(eig(A_aug));

figure;
step(sys_ce);
title('state feedback(order 4) & FullOrder Observer');
grid on;

%% 9) Simulation tests
t = 0:0.001:5;

x0 = [ 0.5;
      -0.2;
       5*pi/180;
       0.1 ];

xhat0_bar = zeros(nx,1);
z0 = [x0; xhat0_bar];

nr = size(N,2);

%% 9-1) zero input
r0 = zeros(length(t), nr);
y0 = lsim(sys_ce, r0, t, z0);

figure;
plot(t, y0);
grid on;
title('9-1) zero input with initial conditions(state feedback(order 4) & FullOrder Observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y0,2)));

%% 9-2) Step reference
z0z = zeros(2*nx,1);
r_step = ones(length(t), nr);
y_step = lsim(sys_ce, r_step, t, z0z);

figure;
plot(t, y_step);
grid on;
title('9-2) Step reference r (state feedback(order 4) & FullOrder Observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_step,2)));

%% 9-3) Sinusoidal reference
r_sin = [sin(2*pi*1*t(:)), ...
         0.5*sin(2*pi*0.5*t(:)), ...
         0.2*sin(2*pi*2*t(:))];

y_sin = lsim(sys_ce, r_sin, t, z0z);

figure;
plot(t, y_sin);
grid on;
title('9-3) Sinusoidal reference r (state feedback(order 4) & FullOrder Observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_sin,2)));

%% 9-4)
Bext = [B*N,      B,           zeros(nx,ny);
        Bbar*N,   Bbar,        Lbar];

Cext = [C zeros(ny,nx)];
Dext = zeros(ny, nr + nu + ny);

sys_ce_ext = ss(A_aug, Bext, Cext, Dext);

%% 9-4a) constant disturbance 
w_const = zeros(nu,1);
w_const(1) = 0.05;
Wc = repmat(w_const.', length(t), 1);

U_const = [r_step, Wc, zeros(length(t),ny)];
y_const = lsim(sys_ce_ext, U_const, t, z0z);

figure;
plot(t, y_const);
grid on;
title('9-4a) constant input disturbance w (state feedback(order 4) & FullOrder Observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_const,2)));

%% 9-4b) sinusoidal disturbance
w_sin = zeros(length(t),nu);
w_sin(:,1) = 0.05*sin(2*pi*3*t(:));

U_wsin = [r_step, w_sin, zeros(length(t),ny)];
y_wsin = lsim(sys_ce_ext, U_wsin, t, z0z);

figure;
plot(t, y_wsin);
grid on;
title('9-4b) sinusoidal input disturbance w(state feedback(order 4) & FullOrder Observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_wsin,2)));

%% 9-4c) measurement noise 
rng(1);
n_noise = 0.1*randn(length(t), ny);

U_noise = [r_step, zeros(length(t),nu), n_noise];
y_noise = lsim(sys_ce_ext, U_noise, t, z0z);

figure;
plot(t, y_noise);
grid on;
title('9-4c) \ measurement noise n (state feedback(order 4) & FullOrder Observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_noise,2)));

