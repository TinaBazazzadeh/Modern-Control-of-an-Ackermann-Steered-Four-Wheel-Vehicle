clc; 
clear; 
close all; 
 
A = [-0.0022,0,0,0;0,-13.8828,0,-1.1393;0,0,0,1;0,1.5933,0,-13.1524]; 
B = [0,0.0006,0.0006,0.0006,0.0006;30.5862,0,0,0,0;0,0,0,0,0;17.6719,-0.0002,-0.0002,0.0002,0.0002]; 
C = [1,0,0,0;0,1,0,0;0,0,0,1]; 
D = [0,0,0,0,0;0,0,0,0,0;0,0,0,0,0]; 
F = [-15,-1,0,0;1,-15,0,0;0,0,-20,0;0,0,0,-10]; 

nx = size(A,1); ny = size(C,1); nu = size(B,2);

Kbar = [1 0 0 0; 
      0 1 0 0; 
      0 0 1 0; 
      0 0 0 1; 
      1 2 3 4];

obsv(F,Kbar); 
rank(obsv(F,Kbar)); 
RHS = B * Kbar;          
P = sylvester(A, -F, RHS);   
disp('Pole placement poles:');
disp(P); 
Pinv = inv(P); 
K = Kbar * Pinv; 
Acl = A - B*K; 
sys_cl = ss(Acl, B, C, D); 
eig(Acl); 
disp('Closed loop poles:');
disp(eig(Acl));
% figure; 
% step(sys_cl) 
% grid on 

%% Static PreFilter
G0 = -C * (Acl \ B);         % = -C*inv(Acl)*B
disp('DC gain matrix G0:');
disp(G0)
N = pinv(G0);
sys = ss(Acl, B, C, D);
G_CL = tf(sys);

%% Closed loop system from reference r to output y (prefilter)
sys_r = ss(Acl, B*N, C, zeros(3,3));
figure;
% step(sys_r)
% title('Pole Placement & Static Prefilter')
% grid on;

%% Reduced order observer (order=0) & state feedback 
O = obsv(A,C);
disp('rank(obsv(A,C)) = ');
disp(rank(O));

[Abar,Bbar,Cbar,T,k] = obsvf(A,B,C);

nuo = length(k);      % unobservable states count (1)
no  = nx - nuo;       % observable states count (3)

Ao = Abar(nuo+1:end, nuo+1:end);
Bo = Bbar(nuo+1:end, :);
Co = Cbar(:,nuo+1:end);

% Reduced-order (zero order here): x_o_hat = Q1 * y
Q1 = pinv(Co);

Tinv = inv(T);

% Build xhat_bar = [0 ; Q1*y]  size nx x 1
Hbar = [zeros(nuo,ny); Q1];        % nx x ny
% xhat = T^{-1} xhat_bar
H = Tinv * Hbar;                   % nx x ny

% Control law: u = -K*xhat + N*r = -K*(H*y) + N*r = -(K*H)*y + N*r
Ky = K * H;                        % (nu x ny)
nr = size(N,2);                    % reference dimension (3)

% Closed loop (static output feedback) from r to y:
% xdot = A x + B( -Ky*y + N*r ) = (A - B*Ky*C)x + B*N*r
A_ro = A - B*Ky*C;
B_ro = B*N;
C_ro = C;
D_ro = zeros(ny,nr);

sys_ro = ss(A_ro, B_ro, C_ro, D_ro);

disp('Closed loop poles (state feedback(order 4) & reduced observer ) :');
disp(eig(A_ro));

figure;
step(sys_ro)
title('state feedback(order 4) & reduced observer ')
grid on;

%% 9) 
t = 0:0.001:5;

x0 = [ 0.5;        % v_xb  (m/s)
      -0.2;        % v_yb  (m/s)
       5*pi/180;   % theta (rad)
       0.1 ];      % omega (rad/s)

%% 9-1) zero input 
%t1=0:0.01:6000;
r0 = zeros(length(t), nr);
y0 = lsim(sys_ro, r0, t, x0);

figure;
plot(t, y0);
grid on;
title('9-1) zero input with initial conditions (state feedback(order 4) & Reduced observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y0,2)));

%% 9-2) Step reference
x0z = zeros(nx,1);
r_step = ones(length(t), nr);
y_step = lsim(sys_ro, r_step, t, x0z);

figure;
plot(t, y_step);
grid on;
title('9-2) Step reference r (state feedback(order 4) & Reduced observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_step,2)));

%% 9-3) Sinusoidal reference 
r_sin = [sin(2*pi*1*t(:)), ...
         0.5*sin(2*pi*0.5*t(:)), ...
         0.2*sin(2*pi*2*t(:))];
y_sin = lsim(sys_ro, r_sin, t, x0z);

figure;
plot(t, y_sin);
grid on;
title('9-3) Sinusoidal reference r (state feedback(order 4) & Reduced observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_sin,2)));

%% 9-4) Disturbances & measurement noise for state feedback(order 4) & reduced order observer 
% Here u uses y_meas = y + n :
% u = -Ky*(y+n) + N*r = -Ky*C*x - Ky*n + N*r
% Plant disturbance w enters additively at plant input: u_total = u + w

% Inputs: [ r ; w ; n ]
% w: nu x 1  (input disturbance)
% n: ny x 1  (measurement noise)

Bext_ro = [B*N,     B,        -B*Ky];          % xdot = A_ro x + B*N r + B*w - B*Ky*n
Cext_ro = C;
Dext_ro = zeros(ny, nr + nu + ny);

sys_ro_ext = ss(A_ro, Bext_ro, Cext_ro, Dext_ro);

%% 9-4a) constant input disturbance w + step r
w_const = zeros(nu,1);
w_const(1) = 0.05;
Wc = repmat(w_const.', length(t), 1);

U_const = [r_step, Wc, zeros(length(t),ny)];
y_const = lsim(sys_ro_ext, U_const, t, x0z);

figure;
plot(t, y_const);
grid on;
title('9-4a)  constant input disturbance w (state feedback(order 4) & Reduced observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_const,2)));

%% 9-4b) sinusoidal input disturbance w 
w_sin = zeros(length(t),nu);
w_sin(:,1) = 0.05*sin(2*pi*3*t(:));

U_wsin = [r_step, w_sin, zeros(length(t),ny)];
y_wsin = lsim(sys_ro_ext, U_wsin, t, x0z);

figure;
plot(t, y_wsin);
grid on;
title('9-4b) sinusoidal input disturbance w (state feedback(order 4) & Reduced observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_wsin,2)));

%% 9-4c) measurement noise n 
rng(1);
n_noise = 2*randn(length(t), ny);

U_noise = [r_step, zeros(length(t),nu), n_noise];
y_noise = lsim(sys_ro_ext, U_noise, t, x0z);

figure;
plot(t, y_noise);
grid on;
title('9-4c) measurement noise n (state feedback(order 4) & Reduced observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_noise,2)));
