%% Design LQR Controller and Apply to Linear & Nonlinear Systems
% Applies LQR controller to both linear and nonlinear vehicle models.
% Generates plots for linear response, nonlinear response, and stability test.

clear; clc; close all;

% ------------------------------------------------------------------
% Linear system matrices
A = [-0.0022, 0, 0, 0;
      0, -13.8828, 0, -1.1393;
      0, 0, 0, 1;
      0, 1.5933, 0, -13.1524];

B = [0, 0.0006, 0.0006, 0.0006, 0.0006;
     30.5862, 0, 0, 0, 0;
     0, 0, 0, 0, 0;
     17.6719, -0.0002, -0.0002, 0.0002, 0.0002];

C = [1, 0, 0, 0;
     0, 1, 0, 0;
     0, 0, 0, 1];

% ------------------------------------------------------------------
% LQR Design
% Q and R weights
Q = diag([10, 100, 1, 50]);  % Emphasize vyb and w control
R = 0.1 * eye(5);             % Penalize control effort

% Compute LQR gain
K_lqr = lqr(A, B, Q, R);

% Static prefilter for LQR (to eliminate steady-state error)
Acl_lqr = A - B*K_lqr;
G0_lqr = -C * (Acl_lqr \ B);
N_lqr = pinv(G0_lqr);

% ------------------------------------------------------------------
% Physical parameters for nonlinear simulation
M = 1500; Iz = 2500; Lf = 1.2; Lr = 1.6; Lt = Lf + Lr;
Kf = 80000; Kr = 90000; Ce = 10;

% ODE solver options
ode_opts = odeset('RelTol',1e-3,'AbsTol',1e-4,'MaxStep',0.05);

% ------------------------------------------------------------------
% Safe vxb function
function vxb_safe = safe_vxb(vxb)
    vxb_min = 0.5;
    if vxb > vxb_min
        vxb_safe = vxb;
    elseif vxb < -vxb_min
        vxb_safe = vxb;
    else
        vxb_safe = sign(vxb + (vxb == 0)) * vxb_min;
    end
end

% ------------------------------------------------------------------
% Nonlinear ODE with LQR control
function dx = vehicle_ode_lqr(~, x, r, K_lqr, N_lqr, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce)
    r = r(:);
    vxb = x(1); vyb = x(2); w = x(4);
    u = -K_lqr*x + N_lqr*r;
    
    Fx1 = u(2); Fx2 = u(3); Fx3 = u(4); Fx4 = u(5);
    Fy_front_total = u(1);
    Fy1 = Fy_front_total/2; Fy4 = Fy_front_total/2;
    
    vxb_safe = safe_vxb(vxb);
    alfa_r = -(vyb - Lr*w) / vxb_safe;
    Fy2 = Kr * alfa_r;
    Fy3 = Kr * alfa_r;
    
    gama = 0;
    Fxf = (Fx1+Fx4)*cos(gama) - (Fy1+Fy4)*sin(gama);
    Fxr = Fx2 + Fx3;
    Fyf = (Fx1+Fx4)*sin(gama) + (Fy1+Fy4)*cos(gama);
    Fyr = Fy2 + Fy3;
    Fx = Fxf + Fxr;
    Fy = Fyf + Fyr;
    
    vxb_dot = w*vyb + (1/M)*(Fx - Ce*(vxb^2));
    vyb_dot = -w*vxb + (1/M)*Fy;
    theta_dot = w;
    w_dot = (1/Iz)*(Lf*Fyf - Lr*Fyr + (Lt/2)*(Fxr - Fxf));
    
    dx = [vxb_dot; vyb_dot; theta_dot; w_dot];
end

% ------------------------------------------------------------------
% SIMULATION 1: Linear system with LQR
% ------------------------------------------------------------------
fprintf('Simulating Linear System with LQR...\n');
t_lin = 0:0.01:5;
r_lin = ones(length(t_lin), 3); % Step reference for 3 outputs

% A_cl = A - B*K_lqr is 4x4
% B_eff = B * N_lqr is 4x3  --> 3 inputs (the references)
% C is 3x4
% D should be 3x3
B_eff = B * N_lqr;
D_eff = zeros(3, 3);

sys_lqr = ss(A - B*K_lqr, B_eff, C, D_eff);
y_lin = lsim(sys_lqr, r_lin, t_lin);

figure;
plot(t_lin, r_lin(:,1), 'k--', 'LineWidth', 2); hold on;
plot(t_lin, y_lin, 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Outputs');
title('Linear System Response with LQR Controller');
legend('Reference', 'v_{xb}', 'v_{yb}', '\omega');

% ------------------------------------------------------------------
% SIMULATION 2: Nonlinear system with LQR
% ------------------------------------------------------------------
fprintf('Simulating Nonlinear System with LQR...\n');
t_nl = 0:0.01:5;
r_nl = ones(length(t_nl), 3);

r_interp = @(tq) interp1(t_nl, r_nl, tq, 'linear', 'extrap');
odefun_nl = @(tq, x) vehicle_ode_lqr(tq, x, r_interp(tq), K_lqr, N_lqr, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce);
[~, x_nl] = ode45(odefun_nl, t_nl, zeros(4,1), ode_opts);
y_nl = [x_nl(:,1), x_nl(:,2), x_nl(:,4)];

figure;
plot(t_nl, r_nl(:,1), 'k--', 'LineWidth', 2); hold on;
plot(t_nl, y_nl, 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Outputs');
title('Nonlinear System Response with LQR Controller');
legend('Reference', 'v_{xb}', 'v_{yb}', '\omega');

% ------------------------------------------------------------------
% SIMULATION 3: Nonlinear stability test (zero reference, nonzero ICs)
% ------------------------------------------------------------------
fprintf('Stability Test: Nonlinear System with LQR...\n');
t_stab = 0:0.01:10;
x0_stab = [0.5; -0.2; 5*pi/180; 0.1];
r_stab = zeros(length(t_stab), 3);

r_interp_stab = @(tq) interp1(t_stab, r_stab, tq, 'linear', 'extrap');
odefun_stab = @(tq, x) vehicle_ode_lqr(tq, x, r_interp_stab(tq), K_lqr, N_lqr, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce);
[~, x_stab] = ode45(odefun_stab, t_stab, x0_stab, ode_opts);
y_stab = [x_stab(:,1), x_stab(:,2), x_stab(:,4)];

figure;
plot(t_stab, y_stab, 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Outputs');
title('Nonlinear Stability Test with LQR (Zero Reference, Nonzero ICs)');
legend('v_{xb}', 'v_{yb}', '\omega');