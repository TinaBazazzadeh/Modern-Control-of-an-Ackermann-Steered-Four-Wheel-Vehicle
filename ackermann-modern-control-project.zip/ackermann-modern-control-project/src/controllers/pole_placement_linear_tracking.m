clc; 
clear; 
close all; 
 
A = [-0.0022,0,0,0;0,-13.8828,0,-1.1393;0,0,0,1;0,1.5933,0,-13.1524]; 
B = [0,0.0006,0.0006,0.0006,0.0006;30.5862,0,0,0,0;0,0,0,0,0;17.6719,-0.0002,-0.0002,0.0002,0.0002]; 
C = [1,0,0,0;0,1,0,0;0,0,0,1]; 
D = [0,0,0,0,0;0,0,0,0,0;0,0,0,0,0]; 
F = [-15,-1,0,0;1,-15,0,0;0,0,-20,0;0,0,0,-10]; 

% Controlable?
Co = ctrb(A, B);
unco = length(A) - rank(Co);
fprintf('uncontrolable states: %d\n', unco);


nx = size(A,1); ny = size(C,1); nu = size(B,2);


Kbar = [1 0 0 0; 
      0 1 0 0; 
      0 0 1 0; 
      0 0 0 1; 
      1 2 3 4]; 
obsv(F,Kbar); 
rank(obsv(F,Kbar)); 
RHS = B * Kbar;          
P = sylvester(A, -F, RHS);   

disp('Pole-placement poles:');
disp(P); 
Pinv = inv(P) 
K = Kbar * Pinv 
Acl = A - B*K; 
sys_cl = ss(Acl, B, C, D); 
eig(Acl) 

disp('Closed-loop poles:');
disp(eig(Acl));

figure; 
step(sys_cl) 
grid on 

%% Static PreFilter

G0 = -C * (Acl \ B);         % = -C*inv(Acl)*B
disp('DC gain matrix G0:');
disp(G0)
N = pinv(G0);
sys = ss(Acl, B, C, D);
G_CL = tf(sys)

%% Closed-loop system from reference r to output y (prefilter)
sys_r = ss(Acl, B*N, C, zeros(3,3));

figure;
step(sys_r)
title('Pole Placement & Static Prefilter')
grid on;

%%  Reference tracking test with lsim
t = 0:0.01:5;
r = ones(length(t),3);
y = lsim(sys_r, r, t);

figure;
% Plot the reference first (using only the first column since they are all 1)
plot(t, r(:,1), 'k--', 'LineWidth', 2); 
hold on; 

% Plot the outputs
plot(t, y, 'LineWidth', 1.5);

grid on;
xlabel('Time (s)');
ylabel('Outputs');

% Update legend to include Reference
legend('Reference (r)', 'y_1', 'y_2', 'y_3');
title('Tracking r = [1;1;1] with Pole Placement & Static Prefilter');
%% Sinusoidal Reference Tracking Test
t_sine = 0:0.01:10;           % Time vector
freq =10 ;                   % Frequency in rad/s
% Create a 3-channel sinusoidal reference (for y1, y2, y3)
r_sine = [sin(freq*t_sine)', sin(freq*t_sine)', sin(freq*t_sine)'];

% Simulate the system with the prefilter N applied
% sys_r was defined as: ss(Acl, B*N, C, zeros(3,3))
y_sine = lsim(sys_r, r_sine, t_sine);

figure;
plot(t_sine, r_sine(:,1), 'k--', 'LineWidth', 1); hold on; % Plot Reference
plot(t_sine, y_sine, 'LineWidth', 1.5);                   % Plot Outputs
grid on;
xlabel('Time (s)');
ylabel('Amplitude');
legend('Reference', 'y_1', 'y_2', 'y_3');
title(['Sinusoidal Tracking at \omega = 0.5', ' rad/s (Static Prefilter)']);

%% zero input with intial conditions
x0 = [ 0.5;     % v_xb  (m/s)
      -0.2;     % v_yb  (m/s)
       5*pi/180;% theta (≈ 5 degrees)
       0.1 ];   % omega (rad/s)

sys_x0 = ss(Acl, zeros(4,3), C, zeros(3,3));
figure;
initial(sys_x0, x0)
grid on
title('Response with r = 0 and nonzero initial conditions')
xlabel('Time (s)')
ylabel('Outputs')
legend('y_1','y_2','y_3')

% step refrence input
step(sys_r)
grid on
title('Step response without integral tracking')

% sinusoidal refrence input
t2 = 0:0.01:20;
r = [sin(0.5*t2)' sin(0.5*t2)' sin(0.5*t2)'];
y = lsim(sys_r, r, t2);

figure;
plot(t2,y), grid on
title('Response to sinusoidal reference without integral tracking(Pole Placement & prefilter)')
legend('y_1','y_2','y_3')

% constant disturbance
d = 0.2*ones(length(t),1);
% u_dist = [d zeros(length(t),4)];
u_dist = repmat(d,1,5);   % disturbance on all inputs
y = lsim(ss(Acl,B,C,D), u_dist, t);

figure;
plot(t,y), grid on
title('Response to step disturbance')

% sinusoidal disturbance
t3 = 0:0.01:50;
omega_d = 0.5;
d1 = 0.2*sin(omega_d*t3);

u_dist = repmat(d1',1,5);   % disturbance on all inputs

sys_ud = ss(Acl, B, C, D);
y = lsim(sys_ud, u_dist, t3);

figure;
plot(t3,y,'LineWidth',1.2)
grid on
title('Response to sinusoidal disturbance on all inputs')
xlabel('Time (s)')
ylabel('Outputs')
legend('y_1','y_2','y_3')

% input noise
t = 0:0.1:10;

noise_amp = 0.05;                      
noise = noise_amp*randn(length(t),5); 

y = lsim(sys_ud, noise, t);

figure;
plot(t, y)
grid on
xlabel('Time (s)')
ylabel('Outputs')
title('Response to input noise')
legend('y_1','y_2','y_3')


%% Integral action INSIDE feedback loop (correct structure)

kI = 0.01;
Ki = kI * ones(nu, ny);   
   

A_aug = [ A - B*K      ,  -B*Ki ;
         -C            ,   zeros(ny) ];

B_aug = [ B*N ;
          eye(ny) ];

C_aug = [ C , zeros(ny) ];
D_aug = zeros(ny);

sys_int = ss(A_aug, B_aug, C_aug, D_aug);

%% Step reference (plot r and y together)
t = 0:0.01:10;
r = ones(length(t), ny);   % step reference for all outputs

y = lsim(sys_int, r, t);

figure;
plot(t, r(:,1), 'k--', 'LineWidth', 2); hold on;   % reference
plot(t, y, 'LineWidth', 1.5);                     % outputs
grid on;

xlabel('Time (s)');
ylabel('Outputs');
title('Step Reference with Integral Action Inside Feedback Loop');
legend('Reference', 'y_1', 'y_2', 'y_3');


%% Sinusoidal reference
t = 0:0.01:20;
r = [sin(0.5*t)' sin(0.5*t)' sin(0.5*t)'];

y = lsim(sys_int, r, t);

figure;
plot(t, r(:,1), 'k--', 'LineWidth', 1.8); hold on;   % reference
plot(t, y, 'LineWidth', 1.5);                        % outputs
grid on;

xlabel('Time (s)');
ylabel('Outputs');
title('Sinusoidal Reference with Integral Action Inside Feedback Loop');
legend('Reference', 'y_1', 'y_2', 'y_3');
%%
A_aug
B_aug
C_aug
D_aug

