%% Complete Nonlinear Simulation: All Requested Plots
% Applies linear controller to exact nonlinear vehicle dynamics.
% Generates:
% 1. Step response without integral 
% 2. Pole placement & prefilter 
% 3. Step response per input 
% 4. Sinusoidal reference response
% 5. Constant disturbance response
% 6. Sinusoidal disturbance response
% 7. Noise response

clear; clc; close all;

% ------------------------------------------------------------------
% Linear controller
A = [-0.0022, 0, 0, 0;
      0, -13.8828, 0, -1.1393;
      0, 0, 0, 1;
      0, 1.5933, 0, -13.1524];

B = [0, 0.0006, 0.0006, 0.0006, 0.0006;
     30.5862, 0, 0, 0, 0;
     0, 0, 0, 0, 0;
     17.6719, -0.0002, -0.0002, 0.0002, 0.0002];

C = [1, 0, 0, 0;
     0, 1, 0, 0;
     0, 0, 0, 1];

Kbar = [1 0 0 0;
        0 1 0 0;
        0 0 1 0;
        0 0 0 1;
        1 2 3 4];
F = [-15,-1,0,0; 1,-15,0,0; 0,0,-20,0; 0,0,0,-10];
RHS = B * Kbar;
P = sylvester(A, -F, RHS);
Pinv = inv(P);
K = Kbar * Pinv;
Acl = A - B*K;
G0 = -C * (Acl \ B);
N = pinv(G0);

% Integral action 
nu = size(B,2); ny = size(C,1);
kI = 0.01;
Ki = kI * ones(nu, ny);

% ------------------------------------------------------------------
% Physical parameters (typical values)
M = 1500; Iz = 2500; Lf = 1.2; Lr = 1.6; Lt = Lf + Lr;
Kf = 80000; Kr = 90000; Ce = 10;

% ODE solver options for speed
ode_opts = odeset('RelTol',1e-3,'AbsTol',1e-4,'MaxStep',0.05);

% ------------------------------------------------------------------
% Safe longitudinal velocity function
% ------------------------------------------------------------------
function vxb_safe = safe_vxb(vxb)
    vxb_min = 0.5; % [m/s] - minimum safe speed
    if vxb > vxb_min
        vxb_safe = vxb;
    elseif vxb < -vxb_min
        vxb_safe = vxb;
    else
        vxb_safe = sign(vxb + (vxb == 0)) * vxb_min;
    end
end

% ------------------------------------------------------------------
% Core ODE functions (exact nonlinear dynamics)
% ------------------------------------------------------------------
function dx = vehicle_ode(~, x, r, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce)
    r = r(:);
    vxb = x(1); vyb = x(2); w = x(4);
    u = -K*x + N*r;
    
    Fx1 = u(2); Fx2 = u(3); Fx3 = u(4); Fx4 = u(5);
    Fy_front_total = u(1);
    Fy1 = Fy_front_total/2; Fy4 = Fy_front_total/2;
    
    vxb_safe = safe_vxb(vxb);
    alfa_r = -(vyb - Lr*w) / vxb_safe;
    Fy2 = Kr * alfa_r;
    Fy3 = Kr * alfa_r;
    
    gama = 0;
    Fxf = (Fx1+Fx4)*cos(gama) - (Fy1+Fy4)*sin(gama);
    Fxr = Fx2 + Fx3;
    Fyf = (Fx1+Fx4)*sin(gama) + (Fy1+Fy4)*cos(gama);
    Fyr = Fy2 + Fy3;
    Fx = Fxf + Fxr;
    Fy = Fyf + Fyr;
    
    vxb_dot = w*vyb + (1/M)*(Fx - Ce*(vxb^2));
    vyb_dot = -w*vxb + (1/M)*Fy;
    theta_dot = w;
    w_dot = (1/Iz)*(Lf*Fyf - Lr*Fyr + (Lt/2)*(Fxr - Fxf));
    
    dx = [vxb_dot; vyb_dot; theta_dot; w_dot];
end

function dx = vehicle_ode_dist(~, x, r, d, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce)
    r = r(:); d = d(:);
    vxb = x(1); vyb = x(2); w = x(4);
    u = -K*x + N*r + d;
    
    Fx1 = u(2); Fx2 = u(3); Fx3 = u(4); Fx4 = u(5);
    Fy_front_total = u(1);
    Fy1 = Fy_front_total/2; Fy4 = Fy_front_total/2;
    
    vxb_safe = safe_vxb(vxb);
    alfa_r = -(vyb - Lr*w) / vxb_safe;
    Fy2 = Kr * alfa_r;
    Fy3 = Kr * alfa_r;
    
    gama = 0;
    Fxf = (Fx1+Fx4)*cos(gama) - (Fy1+Fy4)*sin(gama);
    Fxr = Fx2 + Fx3;
    Fyf = (Fx1+Fx4)*sin(gama) + (Fy1+Fy4)*cos(gama);
    Fyr = Fy2 + Fy3;
    Fx = Fxf + Fxr;
    Fy = Fyf + Fyr;
    
    vxb_dot = w*vyb + (1/M)*(Fx - Ce*(vxb^2));
    vyb_dot = -w*vxb + (1/M)*Fy;
    theta_dot = w;
    w_dot = (1/Iz)*(Lf*Fyf - Lr*Fyr + (Lt/2)*(Fxr - Fxf));
    
    dx = [vxb_dot; vyb_dot; theta_dot; w_dot];
end

% ------------------------------------------------------------------
% Simulation functions
% ------------------------------------------------------------------
function [t_out, y_out] = simulate_ref(tvec, x0, rvec, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce, ode_opts)
    r_interp = @(tq) interp1(tvec, rvec, tq, 'linear', 'extrap');
    odefun = @(tq, x) vehicle_ode(tq, x, r_interp(tq), K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce);
    [~, x_out] = ode45(odefun, tvec, x0, ode_opts);
    y_out = [x_out(:,1), x_out(:,2), x_out(:,4)];
    t_out = tvec;
end

function [t_out, y_out] = simulate_dist(tvec, x0, dvec, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce, ode_opts)
    rvec = zeros(size(dvec,1), 3);
    r_interp = @(tq) interp1(tvec, rvec, tq, 'linear', 'extrap');
    d_interp = @(tq) interp1(tvec, dvec, tq, 'linear', 'extrap');
    odefun = @(tq, x) vehicle_ode_dist(tq, x, r_interp(tq), d_interp(tq), K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce);
    [~, x_out] = ode45(odefun, tvec, x0, ode_opts);
    y_out = [x_out(:,1), x_out(:,2), x_out(:,4)];
    t_out = tvec;
end

% ------------------------------------------------------------------
% PLOT 0: Zero Reference, Nonzero Initial Conditions (Stability Test)
% ------------------------------------------------------------------
fprintf('Plot 0: Zero Reference, Nonzero Initial Conditions (Stability Test)...\n');
t0 = 0:0.01:10;
x0_stability = [0.5; -0.2; 5*pi/180; 0.1];  
r0 = zeros(length(t0), 3);  % zero reference

[~, y0] = simulate_ref(t0, x0_stability, r0, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce, ode_opts);

figure('Name','Stability Test: Zero Reference, Nonzero ICs','NumberTitle','off');
plot(t0, y0, 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Outputs');
title('Zero Reference, Nonzero Initial Conditions (Stability & Transient Response)');
legend('v_{xb}', 'v_{yb}', '\omega');

% ------------------------------------------------------------------
% PLOT 1: Step response without integral tracking 
% ------------------------------------------------------------------
fprintf('Plot 1: Step response without integral tracking...\n');
t1 = 0:0.01:0.8;
x0 = [0;0;0;0];

figure('Name','Step response without integral tracking','NumberTitle','off');
title('Step response without integral tracking');

for ch_in = 1:3
    for ch_out = 1:3
        subplot(3,3,(ch_in-1)*3 + ch_out);
        rvec = zeros(length(t1), 3);
        rvec(:, ch_in) = 1;
        [~, y] = simulate_ref(t1, x0, rvec, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce, ode_opts);
        plot(t1, y(:,ch_out), 'LineWidth', 1.5);
        grid on;
        xlabel('Time (s)');
        ylabel(['To: Out(', num2str(ch_out), ')']);
        title(['From: In(', num2str(ch_in), ')']);
        ylim([-1, 1]);
    end
end

% ------------------------------------------------------------------
% PLOT 2: Pole Placement & Static Prefilter 
% ------------------------------------------------------------------
fprintf('Plot 2: Pole Placement & Static Prefilter...\n');
t2 = 0:0.01:0.8;
x0 = [0;0;0;0];

figure('Name','Pole Placement & Static Prefilter','NumberTitle','off');
title('Pole Placement & Static Prefilter');

for ch_in = 1:3
    for ch_out = 1:3
        subplot(3,3,(ch_in-1)*3 + ch_out);
        rvec = zeros(length(t2), 3);
        rvec(:, ch_in) = 1;
        [~, y] = simulate_ref(t2, x0, rvec, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce, ode_opts);
        plot(t2, y(:,ch_out), 'LineWidth', 1.5);
        grid on;
        xlabel('Time (s)');
        ylabel(['To: Out(', num2str(ch_out), ')']);
        title(['From: In(', num2str(ch_in), ')']);
        ylim([-1, 1]);
    end
end

% ------------------------------------------------------------------
% PLOT 3: Step Response 
% ------------------------------------------------------------------
fprintf('Plot 3: Step Response (each input separately)...\n');
t3 = 0:0.01:1;
x0 = [0;0;0;0];

figure('Name','Step Response','NumberTitle','off');
title('Step Response');

for ch_in = 1:5
    for ch_out = 1:3
        subplot(3,5,(ch_in-1)*3 + ch_out);
        dvec = zeros(length(t3), 5);
        dvec(:, ch_in) = 1;
        [~, y] = simulate_dist(t3, x0, dvec, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce, ode_opts);
        plot(t3, y(:,ch_out), 'LineWidth', 1.5);
        grid on;
        xlabel('Time (s)');
        ylabel(['To: Out(', num2str(ch_out), ')']);
        title(['From: In(', num2str(ch_in), ')']);
        ylim([-0.5, 3.5]);
    end
end

% ------------------------------------------------------------------
% PLOT 4: Sinusoidal Reference Response
% ------------------------------------------------------------------
fprintf('Plot 4: Sinusoidal Reference Response...\n');
t4 = 0:0.01:10;
x0 = [0;0;0;0];
omega_r = 0.5;
r4 = [sin(omega_r*t4)', sin(omega_r*t4)', sin(omega_r*t4)'];

[~, y4] = simulate_ref(t4, x0, r4, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce, ode_opts);

figure;
plot(t4, r4(:,1), 'k--', 'LineWidth', 1.5); hold on;
plot(t4, y4, 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Amplitude');
title('Sinusoidal Reference Response');
legend('Reference', 'v_{xb}', 'v_{yb}', '\omega');

% ------------------------------------------------------------------
% PLOT 5: Constant Disturbance Response
% ------------------------------------------------------------------
fprintf('Plot 5: Constant Disturbance Response...\n');
t5 = 0:0.01:10;
x0 = [0;0;0;0];
d5 = 0.2 * ones(length(t5), 5);

[~, y5] = simulate_dist(t5, x0, d5, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce, ode_opts);

figure;
plot(t5, y5, 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Outputs');
title('Response to Constant Input Disturbance');
legend('v_{xb}', 'v_{yb}', '\omega');

% ------------------------------------------------------------------
% PLOT 6: Sinusoidal Disturbance Response
% ------------------------------------------------------------------
fprintf('Plot 6: Sinusoidal Disturbance Response...\n');
t6 = 0:0.01:20;
x0 = [0;0;0;0];
omega_d = 0.5;
d6 = 0.2 * sin(omega_d * t6);
d6 = repmat(d6', 1, 5);

[~, y6] = simulate_dist(t6, x0, d6, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce, ode_opts);

figure;
plot(t6, y6, 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Outputs');
title('Response to Sinusoidal Input Disturbance');
legend('v_{xb}', 'v_{yb}', '\omega');

% ------------------------------------------------------------------
% PLOT 7: Noise Response
% ------------------------------------------------------------------
fprintf('Plot 7: Noise Response...\n');
t7 = 0:0.01:10;
x0 = [0;0;0;0];
noise_amp = 0.05;
d7 = noise_amp * randn(length(t7), 5);

[~, y7] = simulate_dist(t7, x0, d7, K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce, ode_opts);

figure;
plot(t7, y7, 'LineWidth', 1);
grid on;
xlabel('Time (s)');
ylabel('Outputs');
title('Response to Input Noise');
legend('v_{xb}', 'v_{yb}', '\omega');