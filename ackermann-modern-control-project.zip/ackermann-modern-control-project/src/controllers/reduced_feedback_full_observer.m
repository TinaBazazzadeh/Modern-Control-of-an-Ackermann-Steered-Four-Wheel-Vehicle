clc; 
clear; 
close all; 
 
A = [-0.0022,0,0,0;
     0,-13.8828,0,-1.1393;
     0,0,0,1;
     0,1.5933,0,-13.1524]; 

B = [0,0.0006,0.0006,0.0006,0.0006;
     30.5862,0,0,0,0;
     0,0,0,0,0;
     17.6719,-0.0002,-0.0002,0.0002,0.0002]; 

C = [1,0,0,0;
     0,1,0,0;
     0,0,0,1]; 

D = zeros(3,5); 

nx = size(A,1); ny = size(C,1); nu = size(B,2);

disp('rank(ctrb(A,B)) = '); disp(rank(ctrb(A,B)));
disp('rank(obsv(A,C)) = '); disp(rank(obsv(A,C)));

%% 1) State-feedback design on OBSERVABLE SUBSYSTEM (order 3)
% Observable states : x1, x2, x4
idx = [1 2 4];              % [vx, vy, omega]
Ar  = A(idx, idx);          % 3x3
Br  = B(idx, :);            % 3x5

disp('rank(ctrb(Ar,Br)) = '); disp(rank(ctrb(Ar,Br)));

pK = [-15, -25, -18]; 
Kr = place(Ar, Br, pK);           % 5x3

K = zeros(nu, nx);
K(:, idx) = Kr;                   % columns 1,2,4
K(:, 3)   = 0;                    % no x3 feedback

Acl = A - B*K;

disp('Closed loop poles with 3rd order state feedback:');
disp(eig(Acl));

sys_cl = ss(Acl, B, C, D); 
figure; step(sys_cl); grid on;
title('Closed loop (State Feedback on Observable Subsystem)');

%% 2) Static Prefilter N
sys = ss(Acl, B, C, D);
sys_min = minreal(sys, 1e-8);
G0 = dcgain(sys_min);

if any(~isfinite(G0), 'all')
    eps0 = 1e-3;
    G0 = -C * ((Acl - eps0*eye(nx)) \ B);
end

disp('DC gain matrix G0:');
disp(G0)

N = pinv(G0);

sys_r = ss(Acl, B*N, C, zeros(ny, size(N,2)));
figure; step(sys_r); grid on;
title('State Feedback (order 3) & Static Prefilter');

%% 3) Reduced-order observer & controller 

%   z_dot = F z + T B u + L y
%   u     = -K Q1 y - K Q2 z + N r
% Closed-loop in (x,z):
%   x_dot = (A - B K Q1 C) x  - B K Q2 z + B N r
%   z_dot = (L C - T B K Q1 C) x + (F - T B K Q2) z + T B N r
%
% Here: n=4, q=3 => n-q=1  (z is scalar)

% --- Choose Q1, Q2 so that xhat = Q1 y + Q2 z corresponds to:
%     xhat1 = y1, xhat2 = y2, xhat4 = y3, xhat3 = z
Q1 = [1 0 0;   % x1 from y1
      0 1 0;   % x2 from y2
      0 0 0;   % x3 not in y
      0 0 1];  % x4 from y3

Q2 = [0; 0; 1; 0];   % z represents x3 estimate

% --- Choose T, L, F to match lecture condition (-T A + L C + F T = 0)
% For this system, pick T = [0 0 1 0] (extract x3-row) and F=0, L=[0 0 1]
% so that: -T*A + L*C + F*T = -[0 0 0 1] + [0 0 0 1] + 0 = 0
Tred = [0 0 1 0];    % (1x4)
Fred = 0;            % (1x1)
Lred = [0 0 1];      % (1x3)

% Gains in lecture notation:
KQ1 = K * Q1;      % (nu x ny)
KQ2 = K * Q2;      % (nu x 1)  -> equals K(:,3) which is 0 by your design

% Build closed-loop augmented matrices (x,z) with reference r
nr = size(N,2);    % should be 3

A11 = A - B*KQ1*C;         % nx x nx
A12 = -B*KQ2;              % nx x 1

A21 = Lred*C - Tred*B*KQ1*C;   % 1 x nx
A22 = Fred - Tred*B*KQ2;       % 1 x 1

B1  = B*N;                 % nx x nr
B2  = (Tred*B)*N;          % 1  x nr

A_aug = [A11  A12;
         A21  A22];

B_aug = [B1;
         B2];

C_aug = [C zeros(ny,1)];
D_aug = zeros(ny,nr);

sys_ro_lecture = ss(A_aug, B_aug, C_aug, D_aug);

disp('Closed-loop poles (reduced-order controller):');
disp(eig(A_aug));

figure; step(sys_ro_lecture); grid on;
title('Reduced-order controller (n-q=1) + K(order3) + N');

%% 9) 
t = 0:0.001:5;

x0 = [ 0.5;
      -0.2;
       5*pi/180;
       0.1 ];

z0 = 0;                  % initial controller state
z0_aug = [x0; z0];

z0z = zeros(nx+1,1);

%% 9-1) zero input
r0 = zeros(length(t), nr);
y0 = lsim(sys_ro_lecture, r0, t, z0_aug);

figure;
plot(t, y0, 'LineWidth', 1.2);
grid on;
title('9-1) zero input with initial conditions(reduced order controller) ');
xlabel('Time (s)'); ylabel('y');
legend('y_1','y_2','y_3');

%% 9-2) Step reference 
r_step = ones(length(t), nr);
y_step = lsim(sys_ro_lecture, r_step, t, z0z);

figure;
plot(t, y_step, 'LineWidth', 1.2);
grid on;
title('9-2) Step reference (reduced order)');
xlabel('Time (s)'); ylabel('y');
legend('y_1','y_2','y_3');

%% 9-3) Sinusoidal reference 
r_sin = [sin(2*pi*1*t(:)), ...
         0.5*sin(2*pi*0.5*t(:)), ...
         0.2*sin(2*pi*2*t(:))];
% r_sin = [sin(2*pi*1*t(:)), ...
%          1*sin(2*pi*1*t(:)), ...
%          1*sin(2*pi*1*t(:))];

y_sin = lsim(sys_ro_lecture, r_sin, t, z0z);

figure;
plot(t, y_sin, 'LineWidth', 1.2);
grid on;
title('9-3) Sinusoidal reference (reduced order )');
xlabel('Time (s)'); ylabel('y');
legend('y_1','y_2','y_3');

%% 9-4) disturbances + measurement noise 
% augmented: [x_dot; z_dot] += [B; Tred*B] * w
B_w = [B;
       Tred*B];            % (nx+1) x nu

Bext = [B_aug, B_w];       % inputs: [r ; w]
Dext = zeros(ny, nr + nu);

sys_ext_rw = ss(A_aug, Bext, C_aug, Dext);

%% 9-4a) constant input disturbance w 
w_const = 0.05 * ones(1, nu);
Wc = repmat(w_const, length(t), 1);

U_rw = [r_step, Wc];
y_const = lsim(sys_ext_rw, U_rw, t, z0z);

figure;
plot(t, y_const, 'LineWidth', 1.2);
grid on;
title('9-4a) constant input disturbance w ');
xlabel('Time (s)'); ylabel('y');
legend('y_1','y_2','y_3');

%% 9-4b) sinusoidal input disturbance w 
w_sin = 0.05*sin(2*pi*3*t(:)) * ones(1,nu);
U_rw2 = [r_step, w_sin];
y_wsin = lsim(sys_ext_rw, U_rw2, t, z0z);

figure;
plot(t, y_wsin, 'LineWidth', 1.2);
grid on;
title('9-4b) sinusoidal input disturbance w ');
xlabel('Time (s)'); ylabel('y');
legend('y_1','y_2','y_3');

%% 9-4c) measurement noise on outputs 
rng(1);
n_noise = 0.006*randn(length(t), ny);
y_noise = y_step + n_noise;   % measured output = y + n

figure;
plot(t, y_noise, 'LineWidth', 1.2);
grid on;
title('9-4c) measurement noise n ');
xlabel('Time (s)'); ylabel('y_meas');
legend('y_1','y_2','y_3');
