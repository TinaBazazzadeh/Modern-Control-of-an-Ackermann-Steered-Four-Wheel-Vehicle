clc; 
clear; 
close all; 
 
A = [-0.0022,0,0,0;
     0,-13.8828,0,-1.1393;
     0,0,0,1;
     0,1.5933,0,-13.1524]; 

B = [0,0.0006,0.0006,0.0006,0.0006;
     30.5862,0,0,0,0;
     0,0,0,0,0;
     17.6719,-0.0002,-0.0002,0.0002,0.0002]; 

C = [1,0,0,0;
     0,1,0,0;
     0,0,0,1]; 

D = zeros(3,5); 

nx = size(A,1); ny = size(C,1); nu = size(B,2);

disp('rank(ctrb(A,B)) = '); disp(rank(ctrb(A,B)));
disp('rank(obsv(A,C)) = '); disp(rank(obsv(A,C)));

%% 1) State feedback design on OBSERVABLE SUBSYSTEM (order 3) 
% Observable states : x1, x2, x4
idx = [1 2 4];              % [vx, vy, omega]
Ar  = A(idx, idx);          % 3x3
Br  = B(idx, :);            % 3x5

% Desired poles for the 3rd order controller
pK = [-15, -25, -18]; 

Kr = place(Ar, Br, pK);           % Kr: nu x 3  (5x3)

K = zeros(nu, nx);
K(:, idx) = Kr;                   % columns 1,2,4 filled
K(:, 3)   = 0;                    % x3(theta) removed by design

Acl = A - B*K;

disp('Closed-loop poles (K order 3 on observable subsystem):');
disp(eig(Acl));

sys_cl = ss(Acl, B, C, D); 
figure; 
step(sys_cl) 
grid on 
title('Closed loop (State Feedback on Observable Subsystem, order 3)');

%% Static PreFilter  

sys = ss(Acl, B, C, D);
sys_min = minreal(sys, 1e-8);
G0 = dcgain(sys_min);

if any(~isfinite(G0), 'all')
    eps0 = 1e-3;
    G0 = -C * ((Acl - eps0*eye(nx)) \ B);
end

disp('DC gain matrix G0:');
disp(G0)

N = pinv(G0);

%% Closed-loop system from reference r to output y (prefilter)
sys_r = ss(Acl, B*N, C, zeros(ny, size(N,2)));
figure;
step(sys_r)
title('State Feedback (order 3) & Static Prefilter')
grid on;

%% Reduced order observer (order 0) & state feedback (output feedback static)

O = obsv(A,C);

[Abar,Bbar,Cbar,T,k] = obsvf(A,B,C);

no  = sum(k);        % observable states count (3)
nuo = nx - no;       % unobservable states count (1)

Ao = Abar(nuo+1:end, nuo+1:end);
Bo = Bbar(nuo+1:end, :);
Co = Cbar(:,nuo+1:end);

% Reduced order (zero order): x_o_hat = Q1 * y
% Q1 = inv(Co)
if size(Co,1) == size(Co,2)
    Q1 = inv(Co);
else
    Q1 = pinv(Co);
end

Tinv = inv(T);

% Build xhat_bar = [0 ; Q1*y]  -> size nx x 1
Hbar = [zeros(nuo,ny); Q1];        % nx x ny
% xhat = T^{-1} xhat_bar
H = Tinv * Hbar;                   % nx x ny

% Control law: u = -K*xhat + N*r = -K*(H*y) + N*r = -(K*H)*y + N*r
Ky = K * H;                        % (nu x ny)
nr = size(N,2);                    % reference dimension (should be 3)

% Closed loop (static output feedback) from r to y:
% xdot = A x + B( -Ky*y + N*r ) = (A - B*Ky*C)x + B*N*r
A_ro = A - B*Ky*C;
B_ro = B*N;
C_ro = C;
D_ro = zeros(ny,nr);

sys_ro = ss(A_ro, B_ro, C_ro, D_ro);

disp('Closed loop poles ( reduced observer )');
disp(eig(A_ro));

figure;
step(sys_ro)
title('State Feedback (order 3) & Reduced Order Observer (order 0) ')
grid on;

%% 9) 
t = 0:0.001:5;

x0 = [ 0.5;        % v_xb  (m/s)
      -0.2;        % v_yb  (m/s)
       5*pi/180;   % theta (rad)
       0.1 ];      % omega (rad/s)

%% 9-1)zero input 
r0 = zeros(length(t), nr);
y0 = lsim(sys_ro, r0, t, x0);

figure;
plot(t, y0, 'LineWidth', 1.2);
grid on;
title('9-1) zero input with initial conditions (Reduced observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y0,2)));

%% 9-2) Step reference
x0z = zeros(nx,1);
r_step = ones(length(t), nr);
y_step = lsim(sys_ro, r_step, t, x0z);

figure;
plot(t, y_step, 'LineWidth', 1.2);
grid on;
title('9-2) Step reference r (Reduced observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_step,2)));

%% 9-3) Sinusoidal reference 
% r_sin = [sin(2*pi*1*t(:)), ...
%          0.5*sin(2*pi*0.5*t(:)), ...
%          0.2*sin(2*pi*2*t(:))];
r_sin = [sin(2*pi*1*t(:)), ...
         1*sin(2*pi*1*t(:)), ...
         1*sin(2*pi*1*t(:))];

y_sin = lsim(sys_ro, r_sin, t, x0z);

figure;
plot(t, y_sin, 'LineWidth', 1.2);
grid on;
title('9-3) Sinusoidal reference r (Reduced observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_sin,2)));

%% 9-4) Disturbances & measurement noise for reduced order observer 
% Inputs: [ r ; w ; n ]
Bext_ro = [B*N,     B,        -B*Ky];
Cext_ro = C;
Dext_ro = zeros(ny, nr + nu + ny);

sys_ro_ext = ss(A_ro, Bext_ro, Cext_ro, Dext_ro);

%% 9-4a) constant input disturbance w 
w_const = zeros(nu,1);
w_const(1) = 0.05;
Wc = repmat(w_const.', length(t), 1);

U_const = [r_step, Wc, zeros(length(t),ny)];
y_const = lsim(sys_ro_ext, U_const, t, x0z);

figure;
plot(t, y_const, 'LineWidth', 1.2);
grid on;
title('9-4a) constant input disturbance w (Reduced observer)');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_const,2)));

%% 9-4b) sinusoidal input disturbance w 
w_sin = zeros(length(t),nu);
w_sin(:,1) = 0.05*sin(2*pi*3*t(:));

U_wsin = [r_step, w_sin, zeros(length(t),ny)];
y_wsin = lsim(sys_ro_ext, U_wsin, t, x0z);

figure;
plot(t, y_wsin, 'LineWidth', 1.2);
grid on;
title('9-4b) sinusoidal input disturbance w (Reduced observer )');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_wsin,2)));

%% 9-4c) measurement noise n 
rng(1);
n_noise = 0.06*randn(length(t), ny);

U_noise = [r_step, zeros(length(t),nu), n_noise];
y_noise = lsim(sys_ro_ext, U_noise, t, x0z);

figure;
plot(t, y_noise, 'LineWidth', 1.2);
grid on;
title('9-4c)  measurement noise n (Reduced observer )');
xlabel('Time (s)'); ylabel('y');
legend(compose('y_%d',1:size(y_noise,2)));
