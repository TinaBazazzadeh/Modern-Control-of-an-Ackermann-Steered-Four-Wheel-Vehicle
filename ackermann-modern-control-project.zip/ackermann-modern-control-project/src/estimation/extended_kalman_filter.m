%% SECTION 12
clear; clc; close all;
tic;

%% ------------------------------------------------------------------
%% ORIGINAL CONTROLLER AND OBSERVER 
%% ------------------------------------------------------------------
A = [-0.0022, 0, 0, 0;
     0, -13.8828, 0, -1.1393;
     0, 0, 0, 1;
     0, 1.5933, 0, -13.1524];

B = [0, 0.0006, 0.0006, 0.0006, 0.0006;
     30.5862, 0, 0, 0, 0;
     0, 0, 0, 0, 0;
     17.6719, -0.0002, -0.0002, 0.0002, 0.0002];

C = [1, 0, 0, 0;
     0, 1, 0, 0;
     0, 0, 0, 1];

% Controller design from your original code
Kbar = [1 0 0 0;
        0 1 0 0;
        0 0 1 0;
        0 0 0 1;
        1 2 3 4];
F = [-15,-1,0,0; 1,-15,0,0; 0,0,-20,0; 0,0,0,-10];
RHS = B * Kbar;
P = sylvester(A, -F, RHS);
Pinv = inv(P);
K = Kbar * Pinv;
G0 = -C * ((A-B*K) \ B);
N = pinv(G0);

% Observer design from your original code
[Abar, Bbar, Cbar, T, k] = obsvf(A, B, C);
Ao = Abar(2:4, 2:4);
Bo = Bbar(2:4, :);
Co = Cbar(:, 2:4);
observer_poles = -30 * ones(1, 3);
L_observer = place(Ao', Co', observer_poles)';
Q1 = inv(Co);

fprintf('CONTROLLER AND OBSERVER DESIGN PRESERVED\n');

%% ------------------------------------------------------------------
%% EKF PARAMETERS AND PHYSICAL CONSTANTS
%% ------------------------------------------------------------------
Q_ekf = diag([0.01, 0.05, 0.02]);
R_ekf = diag([0.01, 0.01, 0.0001]);
M = 1500; Iz = 2500; Lf = 1.2; Lr = 1.6; Lt = Lf + Lr;
Kr = 90000; Ce = 10;
dt = 0.02; t_final = 12;
t_vec = 0:dt:t_final;
n_steps = length(t_vec);
u_max = [500, 5000, 5000, 5000, 5000];
u_min = [-500, -5000, -5000, -5000, -5000];

%% ------------------------------------------------------------------
%% CORE FUNCTIONS
%% ------------------------------------------------------------------
function vxb_safe = safe_vxb(vxb)
    vxb_min = 0.5;
    if abs(vxb) > vxb_min
        vxb_safe = vxb;
    else
        vxb_safe = sign(vxb + (vxb == 0)) * vxb_min;
    end
end

function dx = vehicle_ode(~, x, u, M, Iz, Lf, Lr, Lt, Kr, Ce)
    vxb = x(1); vyb = x(2); w = x(4);
    Fx1 = u(2); Fx2 = u(3); Fx3 = u(4); Fx4 = u(5);
    Fy_front_total = u(1);
    Fy1 = Fy_front_total/2; Fy4 = Fy_front_total/2;
    
    vxb_safe = safe_vxb(vxb);
    alfa_r = -(vyb - Lr*w) / vxb_safe;
    Fy2 = Kr * alfa_r;
    Fy3 = Kr * alfa_r;
    
    Fxf = Fx1 + Fx4; Fxr = Fx2 + Fx3;
    Fyf = Fy1 + Fy4; Fyr = Fy2 + Fy3;
    Fx = Fxf + Fxr; Fy = Fyf + Fyr;
    
    vxb_dot = w*vyb + (Fx - Ce*vxb^2)/M;
    vyb_dot = -w*vxb + Fy/M;
    theta_dot = w;
    w_dot = (Lf*Fyf - Lr*Fyr + (Lt/2)*(Fxr - Fxf))/Iz;
    
    dx = [vxb_dot; vyb_dot; theta_dot; w_dot];
end

function [x_ekf, P] = ekf_predict_linear(x_ekf, theta, P, u, dt, Q_ekf, A, B)
    x_full = [x_ekf(1); x_ekf(2); theta; x_ekf(3)];
    x_full_pred = x_full + dt * (A * x_full + B * u);
    x_ekf_pred = [x_full_pred(1); x_full_pred(2); x_full_pred(4)];
    F_mat = A([1,2,4], [1,2,4]);
    P_pred = F_mat * P * F_mat' + Q_ekf;
    x_ekf = x_ekf_pred;
    P = P_pred;
end

function [x_ekf, P] = ekf_predict_nonlinear(x_ekf, theta, P, u, dt, Q_ekf, M, Iz, Lf, Lr, Lt, Kr, Ce)
    x_full = [x_ekf(1); x_ekf(2); theta; x_ekf(3)];
    k1 = vehicle_ode(0, x_full, u, M, Iz, Lf, Lr, Lt, Kr, Ce);
    k2 = vehicle_ode(0, x_full + 0.5*dt*k1, u, M, Iz, Lf, Lr, Lt, Kr, Ce);
    k3 = vehicle_ode(0, x_full + 0.5*dt*k2, u, M, Iz, Lf, Lr, Lt, Kr, Ce);
    k4 = vehicle_ode(0, x_full + dt*k3, u, M, Iz, Lf, Lr, Lt, Kr, Ce);
    x_full_pred = x_full + (dt/6)*(k1 + 2*k2 + 2*k3 + k4);
    x_ekf_pred = [x_full_pred(1); x_full_pred(2); x_full_pred(4)];
    epsilon = 1e-5;
    F_mat = zeros(3,3);
    for i = 1:3
        x_pert = x_ekf;
        x_pert(i) = x_pert(i) + epsilon;
        x_full_pert = [x_pert(1); x_pert(2); theta; x_pert(3)];
        k1_p = vehicle_ode(0, x_full_pert, u, M, Iz, Lf, Lr, Lt, Kr, Ce);
        k2_p = vehicle_ode(0, x_full_pert + 0.5*dt*k1_p, u, M, Iz, Lf, Lr, Lt, Kr, Ce);
        k3_p = vehicle_ode(0, x_full_pert + 0.5*dt*k2_p, u, M, Iz, Lf, Lr, Lt, Kr, Ce);
        k4_p = vehicle_ode(0, x_full_pert + dt*k3_p, u, M, Iz, Lf, Lr, Lt, Kr, Ce);
        x_full_pert_pred = x_full_pert + (dt/6)*(k1_p + 2*k2_p + 2*k3_p + k4_p);
        x_ekf_pert_pred = [x_full_pert_pred(1); x_full_pert_pred(2); x_full_pert_pred(4)];
        F_mat(:,i) = (x_ekf_pert_pred - x_ekf_pred) / epsilon;
    end
    P_pred = F_mat * P * F_mat' + Q_ekf;
    x_ekf = x_ekf_pred;
    P = P_pred;
end

function [x_ekf, P] = ekf_update(x_ekf, P, y_meas, R_ekf)
    y_pred = x_ekf;
    H = eye(3);
    S = H * P * H' + R_ekf;
    K_gain = P * H' / S;
    x_ekf_updated = x_ekf + K_gain * (y_meas - y_pred);
    P_updated = (eye(3) - K_gain * H) * P;
    x_ekf = x_ekf_updated;
    P = P_updated;
end

%% ------------------------------------------------------------------
%% CREATE ARTIFICIAL IMU SENSOR FOR YAW ANGLE
%% ------------------------------------------------------------------
x0_imu = [15.0; 0.5; 0.1; 0.05];
x_true_imu = zeros(4, n_steps); x_true_imu(:,1) = x0_imu;
for k = 2:n_steps
    odefun = @(t,x) vehicle_ode(t, x, zeros(5,1), M, Iz, Lf, Lr, Lt, Kr, Ce);
    [~, xsol] = ode45(odefun, [t_vec(k-1), t_vec(k)], x_true_imu(:,k-1), odeset('RelTol',1e-3,'AbsTol',1e-4));
    x_true_imu(:,k) = xsol(end,:)';
end
theta_IMU = zeros(1, n_steps);
theta_IMU(1) = x0_imu(3);
for k = 2:n_steps
    theta_IMU(k) = theta_IMU(k-1) + dt * (x_true_imu(4,k-1) + 0.01 * randn);
end

%% ------------------------------------------------------------------
%% TEST 1: ZERO REFERENCE, NONZERO INITIAL CONDITIONS (STABILITY)
%% ------------------------------------------------------------------
fprintf('\n=== TEST 1: ZERO REFERENCE, NONZERO ICs (STABILITY) ===\n');

x0_stability = [0.5; -0.2; 5*pi/180; 0.1];
r0 = zeros(length(t_vec), 3);

% --- LINEAR SYSTEM ---
x_lin_t1 = zeros(4, n_steps); x_lin_t1(:,1) = x0_stability;
x_hat_lin_t1 = zeros(3, n_steps); x_hat_lin_t1(:,1) = [0.5; -0.2; 0.1];
P_lin_t1 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    [x_pred, P_pred] = ekf_predict_linear(x_hat_lin_t1(:,k-1), theta_IMU(k-1), P_lin_t1, zeros(5,1), dt, Q_ekf, A, B);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full, u_max'), u_min');
    x_lin_t1(:,k) = x_lin_t1(:,k-1) + dt * (A * x_lin_t1(:,k-1) + B * u_control);
    y_meas = C * x_lin_t1(:,k) + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_lin_t1(:,k), P_lin_t1] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

% --- NONLINEAR SYSTEM ---
x_nonlin_t1 = zeros(4, n_steps); x_nonlin_t1(:,1) = x0_stability;
x_hat_nonlin_t1 = zeros(3, n_steps); x_hat_nonlin_t1(:,1) = [0.5; -0.2; 0.1];
P_nonlin_t1 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    [x_pred, P_pred] = ekf_predict_nonlinear(x_hat_nonlin_t1(:,k-1), theta_IMU(k-1), P_nonlin_t1, zeros(5,1), dt, Q_ekf, ...
        M, Iz, Lf, Lr, Lt, Kr, Ce);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full, u_max'), u_min');
    odefun = @(t,x) vehicle_ode(t, x, u_control, M, Iz, Lf, Lr, Lt, Kr, Ce);
    [~, xsol] = ode45(odefun, [t_vec(k-1), t_vec(k)], x_nonlin_t1(:,k-1), odeset('RelTol',1e-3,'AbsTol',1e-4));
    x_nonlin_t1(:,k) = xsol(end,:)';
    y_meas = [x_nonlin_t1(1,k); x_nonlin_t1(2,k); x_nonlin_t1(4,k)] + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_nonlin_t1(:,k), P_nonlin_t1] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

figure('Name','TEST 1: Stability Test - LINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, x_lin_t1(1,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Linear: v_{xb}');
subplot(1,3,2); plot(t_vec, x_lin_t1(2,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Linear: v_{yb}');
subplot(1,3,3); plot(t_vec, x_lin_t1(4,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Linear: \omega');

figure('Name','TEST 1: Stability Test - NONLINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, x_nonlin_t1(1,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Nonlinear: v_{xb}');
subplot(1,3,2); plot(t_vec, x_nonlin_t1(2,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Nonlinear: v_{yb}');
subplot(1,3,3); plot(t_vec, x_nonlin_t1(4,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Nonlinear: \omega');

%% ------------------------------------------------------------------
%% TEST 2: STEP RESPONSE
%% ------------------------------------------------------------------
fprintf('\n=== TEST 2: STEP RESPONSE ===\n');

r_step = [1*ones(length(t_vec),1), 0.5*ones(length(t_vec),1), 0.2*ones(length(t_vec),1)];

% --- LINEAR SYSTEM ---
x_lin_t2 = zeros(4, n_steps); x_lin_t2(:,1) = [0;0;0;0];
x_hat_lin_t2 = zeros(3, n_steps); x_hat_lin_t2(:,1) = [0;0;0];
P_lin_t2 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    r_k = r_step(k,:)';
    [x_pred, P_pred] = ekf_predict_linear(x_hat_lin_t2(:,k-1), theta_IMU(k-1), P_lin_t2, zeros(5,1), dt, Q_ekf, A, B);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full + N * r_k, u_max'), u_min');
    x_lin_t2(:,k) = x_lin_t2(:,k-1) + dt * (A * x_lin_t2(:,k-1) + B * u_control);
    y_meas = C * x_lin_t2(:,k) + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_lin_t2(:,k), P_lin_t2] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

% --- NONLINEAR SYSTEM ---
x_nonlin_t2 = zeros(4, n_steps); x_nonlin_t2(:,1) = [0;0;0;0];
x_hat_nonlin_t2 = zeros(3, n_steps); x_hat_nonlin_t2(:,1) = [0;0;0];
P_nonlin_t2 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    r_k = r_step(k,:)';
    [x_pred, P_pred] = ekf_predict_nonlinear(x_hat_nonlin_t2(:,k-1), theta_IMU(k-1), P_nonlin_t2, zeros(5,1), dt, Q_ekf, ...
        M, Iz, Lf, Lr, Lt, Kr, Ce);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full + N * r_k, u_max'), u_min');
    odefun = @(t,x) vehicle_ode(t, x, u_control, M, Iz, Lf, Lr, Lt, Kr, Ce);
    [~, xsol] = ode45(odefun, [t_vec(k-1), t_vec(k)], x_nonlin_t2(:,k-1), odeset('RelTol',1e-3,'AbsTol',1e-4));
    x_nonlin_t2(:,k) = xsol(end,:)';
    y_meas = [x_nonlin_t2(1,k); x_nonlin_t2(2,k); x_nonlin_t2(4,k)] + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_nonlin_t2(:,k), P_nonlin_t2] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

figure('Name','TEST 2: Step Response - LINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, r_step(:,1), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t2(1,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Linear: v_{xb}'); legend('Ref','Resp');
subplot(1,3,2); plot(t_vec, r_step(:,2), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t2(2,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Linear: v_{yb}'); legend('Ref','Resp');
subplot(1,3,3); plot(t_vec, r_step(:,3), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t2(4,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Linear: \omega'); legend('Ref','Resp');

figure('Name','TEST 2: Step Response - NONLINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, r_step(:,1), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t2(1,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Nonlinear: v_{xb}'); legend('Ref','Resp');
subplot(1,3,2); plot(t_vec, r_step(:,2), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t2(2,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Nonlinear: v_{yb}'); legend('Ref','Resp');
subplot(1,3,3); plot(t_vec, r_step(:,3), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t2(4,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Nonlinear: \omega'); legend('Ref','Resp');

%% ------------------------------------------------------------------
%% TEST 3: SINUSOIDAL REFERENCE
%% ------------------------------------------------------------------
fprintf('\n=== TEST 3: SINUSOIDAL REFERENCE ===\n');

omega_r = 0.5;
r_sine = [sin(omega_r*t_vec)', 0.5*sin(omega_r*t_vec)', 0.3*sin(omega_r*t_vec)'];

% --- LINEAR SYSTEM ---
x_lin_t3 = zeros(4, n_steps); x_lin_t3(:,1) = [0;0;0;0];
x_hat_lin_t3 = zeros(3, n_steps); x_hat_lin_t3(:,1) = [0;0;0];
P_lin_t3 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    r_k = r_sine(k,:)';
    [x_pred, P_pred] = ekf_predict_linear(x_hat_lin_t3(:,k-1), theta_IMU(k-1), P_lin_t3, zeros(5,1), dt, Q_ekf, A, B);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full + N * r_k, u_max'), u_min');
    x_lin_t3(:,k) = x_lin_t3(:,k-1) + dt * (A * x_lin_t3(:,k-1) + B * u_control);
    y_meas = C * x_lin_t3(:,k) + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_lin_t3(:,k), P_lin_t3] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

% --- NONLINEAR SYSTEM ---
x_nonlin_t3 = zeros(4, n_steps); x_nonlin_t3(:,1) = [0;0;0;0];
x_hat_nonlin_t3 = zeros(3, n_steps); x_hat_nonlin_t3(:,1) = [0;0;0];
P_nonlin_t3 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    r_k = r_sine(k,:)';
    [x_pred, P_pred] = ekf_predict_nonlinear(x_hat_nonlin_t3(:,k-1), theta_IMU(k-1), P_nonlin_t3, zeros(5,1), dt, Q_ekf, ...
        M, Iz, Lf, Lr, Lt, Kr, Ce);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full + N * r_k, u_max'), u_min');
    odefun = @(t,x) vehicle_ode(t, x, u_control, M, Iz, Lf, Lr, Lt, Kr, Ce);
    [~, xsol] = ode45(odefun, [t_vec(k-1), t_vec(k)], x_nonlin_t3(:,k-1), odeset('RelTol',1e-3,'AbsTol',1e-4));
    x_nonlin_t3(:,k) = xsol(end,:)';
    y_meas = [x_nonlin_t3(1,k); x_nonlin_t3(2,k); x_nonlin_t3(4,k)] + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_nonlin_t3(:,k), P_nonlin_t3] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

figure('Name','TEST 3: Sinusoidal Reference - LINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, r_sine(:,1), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t3(1,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Linear: v_{xb}'); legend('Ref','Resp');
subplot(1,3,2); plot(t_vec, r_sine(:,2), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t3(2,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Linear: v_{yb}'); legend('Ref','Resp');
subplot(1,3,3); plot(t_vec, r_sine(:,3), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t3(4,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Linear: \omega'); legend('Ref','Resp');

figure('Name','TEST 3: Sinusoidal Reference - NONLINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, r_sine(:,1), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t3(1,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Nonlinear: v_{xb}'); legend('Ref','Resp');
subplot(1,3,2); plot(t_vec, r_sine(:,2), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t3(2,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Nonlinear: v_{yb}'); legend('Ref','Resp');
subplot(1,3,3); plot(t_vec, r_sine(:,3), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t3(4,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Nonlinear: \omega'); legend('Ref','Resp');

%% ------------------------------------------------------------------
%% TEST 4: CONSTANT DISTURBANCE
%% ------------------------------------------------------------------
fprintf('\n=== TEST 4: CONSTANT DISTURBANCE ===\n');

d_const = 0.2 * ones(length(t_vec), 5);  % 5 inputs disturbance
r_const = [1*ones(length(t_vec),1), 0.3*ones(length(t_vec),1), 0.1*ones(length(t_vec),1)];

% --- LINEAR SYSTEM ---
x_lin_t4 = zeros(4, n_steps); x_lin_t4(:,1) = [0;0;0;0];
x_hat_lin_t4 = zeros(3, n_steps); x_hat_lin_t4(:,1) = [0;0;0];
P_lin_t4 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    r_k = r_const(k,:)';
    d_k = d_const(k,:)';  % 5x1 disturbance vector
    [x_pred, P_pred] = ekf_predict_linear(x_hat_lin_t4(:,k-1), theta_IMU(k-1), P_lin_t4, d_k, dt, Q_ekf, A, B);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full + N * r_k, u_max'), u_min');
    % FIXED: Added disturbance to system dynamics correctly
    x_lin_t4(:,k) = x_lin_t4(:,k-1) + dt * (A * x_lin_t4(:,k-1) + B * (u_control + d_k));
    y_meas = C * x_lin_t4(:,k) + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_lin_t4(:,k), P_lin_t4] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

% --- NONLINEAR SYSTEM ---
x_nonlin_t4 = zeros(4, n_steps); x_nonlin_t4(:,1) = [0;0;0;0];
x_hat_nonlin_t4 = zeros(3, n_steps); x_hat_nonlin_t4(:,1) = [0;0;0];
P_nonlin_t4 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    r_k = r_const(k,:)';
    d_k = d_const(k,:)';  % 5x1 disturbance vector
    [x_pred, P_pred] = ekf_predict_nonlinear(x_hat_nonlin_t4(:,k-1), theta_IMU(k-1), P_nonlin_t4, d_k, dt, Q_ekf, ...
        M, Iz, Lf, Lr, Lt, Kr, Ce);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full + N * r_k, u_max'), u_min');
    odefun = @(t,x) vehicle_ode(t, x, u_control + d_k, M, Iz, Lf, Lr, Lt, Kr, Ce);
    [~, xsol] = ode45(odefun, [t_vec(k-1), t_vec(k)], x_nonlin_t4(:,k-1), odeset('RelTol',1e-3,'AbsTol',1e-4));
    x_nonlin_t4(:,k) = xsol(end,:)';
    y_meas = [x_nonlin_t4(1,k); x_nonlin_t4(2,k); x_nonlin_t4(4,k)] + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_nonlin_t4(:,k), P_nonlin_t4] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

figure('Name','TEST 4: Constant Disturbance - LINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, r_const(:,1), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t4(1,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Linear: v_{xb}'); legend('Ref','Resp');
subplot(1,3,2); plot(t_vec, r_const(:,2), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t4(2,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Linear: v_{yb}'); legend('Ref','Resp');
subplot(1,3,3); plot(t_vec, r_const(:,3), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t4(4,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Linear: \omega'); legend('Ref','Resp');

figure('Name','TEST 4: Constant Disturbance - NONLINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, r_const(:,1), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t4(1,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Nonlinear: v_{xb}'); legend('Ref','Resp');
subplot(1,3,2); plot(t_vec, r_const(:,2), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t4(2,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Nonlinear: v_{yb}'); legend('Ref','Resp');
subplot(1,3,3); plot(t_vec, r_const(:,3), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t4(4,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Nonlinear: \omega'); legend('Ref','Resp');

%% ------------------------------------------------------------------
%% TEST 5: SINUSOIDAL DISTURBANCE
%% ------------------------------------------------------------------
fprintf('\n=== TEST 5: SINUSOIDAL DISTURBANCE ===\n');

omega_d = 0.5;
d_sine = 0.2 * sin(omega_d * t_vec);
d_sine = repmat(d_sine', 1, 5);  % Make it 5 columns

% --- LINEAR SYSTEM ---
x_lin_t5 = zeros(4, n_steps); x_lin_t5(:,1) = [0;0;0;0];
x_hat_lin_t5 = zeros(3, n_steps); x_hat_lin_t5(:,1) = [0;0;0];
P_lin_t5 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    r_k = r_const(k,:)';
    d_k = d_sine(k,:)';  % 5x1 disturbance vector
    [x_pred, P_pred] = ekf_predict_linear(x_hat_lin_t5(:,k-1), theta_IMU(k-1), P_lin_t5, d_k, dt, Q_ekf, A, B);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full + N * r_k, u_max'), u_min');
    x_lin_t5(:,k) = x_lin_t5(:,k-1) + dt * (A * x_lin_t5(:,k-1) + B * (u_control + d_k));
    y_meas = C * x_lin_t5(:,k) + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_lin_t5(:,k), P_lin_t5] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

% --- NONLINEAR SYSTEM ---
x_nonlin_t5 = zeros(4, n_steps); x_nonlin_t5(:,1) = [0;0;0;0];
x_hat_nonlin_t5 = zeros(3, n_steps); x_hat_nonlin_t5(:,1) = [0;0;0];
P_nonlin_t5 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    r_k = r_const(k,:)';
    d_k = d_sine(k,:)';  % 5x1 disturbance vector
    [x_pred, P_pred] = ekf_predict_nonlinear(x_hat_nonlin_t5(:,k-1), theta_IMU(k-1), P_nonlin_t5, d_k, dt, Q_ekf, ...
        M, Iz, Lf, Lr, Lt, Kr, Ce);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full + N * r_k, u_max'), u_min');
    odefun = @(t,x) vehicle_ode(t, x, u_control + d_k, M, Iz, Lf, Lr, Lt, Kr, Ce);
    [~, xsol] = ode45(odefun, [t_vec(k-1), t_vec(k)], x_nonlin_t5(:,k-1), odeset('RelTol',1e-3,'AbsTol',1e-4));
    x_nonlin_t5(:,k) = xsol(end,:)';
    y_meas = [x_nonlin_t5(1,k); x_nonlin_t5(2,k); x_nonlin_t5(4,k)] + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_nonlin_t5(:,k), P_nonlin_t5] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

figure('Name','TEST 5: Sinusoidal Disturbance - LINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, r_const(:,1), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t5(1,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Linear: v_{xb}'); legend('Ref','Resp');
subplot(1,3,2); plot(t_vec, r_const(:,2), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t5(2,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Linear: v_{yb}'); legend('Ref','Resp');
subplot(1,3,3); plot(t_vec, r_const(:,3), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t5(4,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Linear: \omega'); legend('Ref','Resp');

figure('Name','TEST 5: Sinusoidal Disturbance - NONLINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, r_const(:,1), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t5(1,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Nonlinear: v_{xb}'); legend('Ref','Resp');
subplot(1,3,2); plot(t_vec, r_const(:,2), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t5(2,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Nonlinear: v_{yb}'); legend('Ref','Resp');
subplot(1,3,3); plot(t_vec, r_const(:,3), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t5(4,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Nonlinear: \omega'); legend('Ref','Resp');

%% ------------------------------------------------------------------
%% TEST 6: NOISE RESPONSE
%% ------------------------------------------------------------------
fprintf('\n=== TEST 6: NOISE RESPONSE ===\n');

noise_amp = 0.05;
d_noise = noise_amp * randn(length(t_vec), 5);  % 5 inputs noise
r_noise = [1*ones(length(t_vec),1), 0.3*ones(length(t_vec),1), 0.1*ones(length(t_vec),1)];

% --- LINEAR SYSTEM ---
x_lin_t6 = zeros(4, n_steps); x_lin_t6(:,1) = [0;0;0;0];
x_hat_lin_t6 = zeros(3, n_steps); x_hat_lin_t6(:,1) = [0;0;0];
P_lin_t6 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    r_k = r_noise(k,:)';
    d_k = d_noise(k,:)';  % 5x1 noise vector
    [x_pred, P_pred] = ekf_predict_linear(x_hat_lin_t6(:,k-1), theta_IMU(k-1), P_lin_t6, d_k, dt, Q_ekf, A, B);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full + N * r_k, u_max'), u_min');
    x_lin_t6(:,k) = x_lin_t6(:,k-1) + dt * (A * x_lin_t6(:,k-1) + B * (u_control + d_k));
    y_meas = C * x_lin_t6(:,k) + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_lin_t6(:,k), P_lin_t6] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

% --- NONLINEAR SYSTEM ---
x_nonlin_t6 = zeros(4, n_steps); x_nonlin_t6(:,1) = [0;0;0;0];
x_hat_nonlin_t6 = zeros(3, n_steps); x_hat_nonlin_t6(:,1) = [0;0;0];
P_nonlin_t6 = diag([0.5^2, 0.3^2, 0.02^2]);

for k = 2:n_steps
    r_k = r_noise(k,:)';
    d_k = d_noise(k,:)';  % 5x1 noise vector
    [x_pred, P_pred] = ekf_predict_nonlinear(x_hat_nonlin_t6(:,k-1), theta_IMU(k-1), P_nonlin_t6, d_k, dt, Q_ekf, ...
        M, Iz, Lf, Lr, Lt, Kr, Ce);
    x_hat_full = [x_pred(1); x_pred(2); theta_IMU(k); x_pred(3)];
    u_control = max(min(-K * x_hat_full + N * r_k, u_max'), u_min');
    odefun = @(t,x) vehicle_ode(t, x, u_control + d_k, M, Iz, Lf, Lr, Lt, Kr, Ce);
    [~, xsol] = ode45(odefun, [t_vec(k-1), t_vec(k)], x_nonlin_t6(:,k-1), odeset('RelTol',1e-3,'AbsTol',1e-4));
    x_nonlin_t6(:,k) = xsol(end,:)';
    y_meas = [x_nonlin_t6(1,k); x_nonlin_t6(2,k); x_nonlin_t6(4,k)] + [0.1*randn; 0.1*randn; 0.01*randn];
    [x_hat_nonlin_t6(:,k), P_nonlin_t6] = ekf_update(x_pred, P_pred, y_meas, R_ekf);
end

figure('Name','TEST 6: Noise Response - LINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, r_noise(:,1), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t6(1,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Linear: v_{xb}'); legend('Ref','Resp');
subplot(1,3,2); plot(t_vec, r_noise(:,2), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t6(2,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Linear: v_{yb}'); legend('Ref','Resp');
subplot(1,3,3); plot(t_vec, r_noise(:,3), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_lin_t6(4,:), 'b', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Linear: \omega'); legend('Ref','Resp');

figure('Name','TEST 6: Noise Response - NONLINEAR','Position',[100,100,1200,350]);
subplot(1,3,1); plot(t_vec, r_noise(:,1), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t6(1,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{xb} (m/s)'); title('Nonlinear: v_{xb}'); legend('Ref','Resp');
subplot(1,3,2); plot(t_vec, r_noise(:,2), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t6(2,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('v_{yb} (m/s)'); title('Nonlinear: v_{yb}'); legend('Ref','Resp');
subplot(1,3,3); plot(t_vec, r_noise(:,3), 'k--', 'LineWidth', 2); hold on; plot(t_vec, x_nonlin_t6(4,:), 'r', 'LineWidth', 1.5); grid on; xlabel('Time (s)'); ylabel('\omega (rad/s)'); title('Nonlinear: \omega'); legend('Ref','Resp');
