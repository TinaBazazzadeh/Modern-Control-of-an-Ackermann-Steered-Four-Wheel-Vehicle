%% Complete Nonlinear Simulation with Observer Integration - FULLY WORKING WITH PLOTS
clear; clc; close all;
rng(0); % For reproducible noise

%% ------------------------------------------------------------------------
% LINEAR CONTROLLER DESIGN
%% ------------------------------------------------------------------------
A = [-0.0022, 0, 0, 0;
      0, -13.8828, 0, -1.1393;
      0, 0, 0, 1;
      0, 1.5933, 0, -13.1524];

B = [0, 0.0006, 0.0006, 0.0006, 0.0006;
     30.5862, 0, 0, 0, 0;
     0, 0, 0, 0, 0;
     17.6719, -0.0002, -0.0002, 0.0002, 0.0002];

C = [1, 0, 0, 0;
     0, 1, 0, 0;
     0, 0, 0, 1];

% Pole placement and prefilter design
Kbar = [1 0 0 0;
        0 1 0 0;
        0 0 1 0;
        0 0 0 1;
        1 2 3 4];
F = [-15,-1,0,0; 1,-15,0,0; 0,0,-20,0; 0,0,0,-10];
RHS = B * Kbar;
P = sylvester(A, -F, RHS);
Pinv = inv(P);
K = Kbar * Pinv;        % 5x4 controller gain
Acl = A - B*K;
G0 = -C * (Acl \ B);    % 3x5 DC gain
N = pinv(G0);           % 5x3 prefilter

%% ------------------------------------------------------------------------
% OBSERVER DESIGN FOR OBSERVABLE SUBSYSTEM
%% ------------------------------------------------------------------------
[Abar, Bbar, Cbar, T, k] = obsvf(A, B, C);
T_inv = inv(T);

% Observable subsystem (3 states)
Ao = Abar(2:4, 2:4);    % 3x3
Bo = Bbar(2:4, :);      % 3x5
Co = Cbar(:, 2:4);      % 3x3

if rank(obsv(Ao, Co)) < 3
    error('Observable subsystem is not fully observable!');
end

% Full-order observer gain (poles at -30)
L_full = place(Ao', Co', -30*ones(1,3))';

% Reduced-order observer (static inversion)
Q1 = inv(Co);
x1_nominal = 0;

%% ------------------------------------------------------------------------
% PHYSICAL PARAMETERS
%% ------------------------------------------------------------------------
M = 1500; Iz = 2500; Lf = 1.2; Lr = 1.6; Lt = Lf + Lr;
Kr = 90000; Ce = 10;
vxb_min = 0.5;

%% ------------------------------------------------------------------------
% NONLINEAR DYNAMICS FUNCTION
%% ------------------------------------------------------------------------
function dx = vehicle_dynamics(x, u, M, Iz, Lf, Lr, Lt, Kr, Ce, vxb_min)
    vxb = x(1); vyb = x(2); w = x(4);
    Fy_front_total = u(1);
    Fx1 = u(2); Fx2 = u(3); Fx3 = u(4); Fx4 = u(5);
    Fy1 = Fy_front_total/2; Fy4 = Fy_front_total/2;
    
    if abs(vxb) < vxb_min
        vxb_safe = sign(vxb + (vxb == 0)) * vxb_min;
    else
        vxb_safe = vxb;
    end
    
    alfa_r = -(vyb - Lr*w) / vxb_safe;
    Fy2 = Kr * alfa_r;
    Fy3 = Kr * alfa_r;
    
    Fxf = Fx1 + Fx4;
    Fxr = Fx2 + Fx3;
    Fyf = Fy1 + Fy4;
    Fyr = Fy2 + Fy3;
    Fx = Fxf + Fxr;
    Fy = Fyf + Fyr;
    
    vxb_dot = w*vyb + (1/M)*(Fx - Ce*(vxb^2));
    vyb_dot = -w*vxb + (1/M)*Fy;
    theta_dot = w;
    w_dot = (1/Iz)*(Lf*Fyf - Lr*Fyr + (Lt/2)*(Fxr - Fxf));
    dx = [vxb_dot; vyb_dot; theta_dot; w_dot];
end

%% ------------------------------------------------------------------------
% TEST CONFIGURATIONS (ONLY TESTS 1, 2, 3)
%% ------------------------------------------------------------------------
dt = 0.001;
noise_amp_output = 0.02;
noise_amp_process = 0.001;

scenarios = {'ideal',false; 'full_order',false; 'full_order',true; 'reduced_order',false; 'reduced_order',true};
n_scenarios = size(scenarios,1);

test_configs(1).name = 'Zero reference, nonzero ICs (stability)';
test_configs(1).t_final = 8;
test_configs(1).x0 = [0.5; -0.2; 5*pi/180; 0.1];
test_configs(1).r_func = @(t) [0; 0; 0];
test_configs(1).d_func = @(t) zeros(5,1);

test_configs(2).name = 'Step response (tracking)';
test_configs(2).t_final = 5;
test_configs(2).x0 = [0; 0; 0; 0];
test_configs(2).r_func = @(t) (t>=1) * [1; 0.5; 0.2];
test_configs(2).d_func = @(t) zeros(5,1);

test_configs(3).name = 'Sinusoidal reference response';
test_configs(3).t_final = 15;
test_configs(3).x0 = [0; 0; 0; 0];
omega_r = 0.8;
test_configs(3).r_func = @(t) [sin(omega_r*t); 0.5*cos(omega_r*t); 0.3*sin(2*omega_r*t)];
test_configs(3).d_func = @(t) zeros(5,1);

%% ------------------------------------------------------------------------
% MAIN SIMULATION LOOP (ONLY 3 TESTS)
%% ------------------------------------------------------------------------
fprintf('Running simulations...\n');
results = struct();

for test_idx = 1:3
    fprintf('  TEST %d: %s\n', test_idx, test_configs(test_idx).name);
    
    t_test = 0:dt:test_configs(test_idx).t_final;
    N_test = length(t_test);
    
    % Initialize storage for this test
    for sc = 1:n_scenarios
        results(test_idx).t = t_test;
        results(test_idx).name = test_configs(test_idx).name;
        results(test_idx).scenario{sc} = scenarios{sc,1};
        results(test_idx).has_noise(sc) = scenarios{sc,2};
        results(test_idx).x(:,:,sc) = zeros(4, N_test);
        results(test_idx).x_hat(:,:,sc) = zeros(4, N_test);
        results(test_idx).y(:,:,sc) = zeros(3, N_test);
        results(test_idx).u(:,:,sc) = zeros(5, N_test);
    end
    
    % Generate reference and disturbance profiles
    r_profile = zeros(3, N_test);
    d_profile = zeros(5, N_test);
    for k = 1:N_test
        r_profile(:,k) = test_configs(test_idx).r_func(t_test(k));
        d_profile(:,k) = test_configs(test_idx).d_func(t_test(k));
    end
    results(test_idx).r = r_profile;
    results(test_idx).d = d_profile;
    
    % Run each scenario
    for sc = 1:n_scenarios
        observer_type = scenarios{sc,1};
        add_noise = scenarios{sc,2};
        
        x = test_configs(test_idx).x0;
        
        % Observer initialization
        if strcmp(observer_type, 'ideal')
            x_hat = x;
        elseif strcmp(observer_type, 'full_order')
            x_bar0 = T * test_configs(test_idx).x0;
            x_o_hat = x_bar0(2:4) + 0.5*randn(3,1);
        else % reduced_order
            y0 = C * test_configs(test_idx).x0;
            if add_noise
                y0 = y0 + noise_amp_output * randn(3,1);
            end
            x_o_hat = Q1 * y0;
        end
        
        % Simulation loop
        for k = 1:N_test
            results(test_idx).x(:,k,sc) = x;
            
            % Measurement (with optional noise)
            y = C * x;
            if add_noise && ~strcmp(observer_type, 'ideal')
                y = y + noise_amp_output * randn(3,1);
            end
            results(test_idx).y(:,k,sc) = y;
            
            % State estimation
            if strcmp(observer_type, 'ideal')
                x_hat = x;
            elseif strcmp(observer_type, 'full_order')
                if k == 1
                    u_prev = zeros(5,1);
                else
                    u_prev = results(test_idx).u(:,k-1,sc);
                end
                x_o_hat = x_o_hat + dt * (Ao*x_o_hat + Bo*u_prev + L_full*(y - Co*x_o_hat));
                x_bar_hat = [x1_nominal; x_o_hat];
                x_hat = T_inv * x_bar_hat;
            else % reduced_order
                x_o_hat = Q1 * y;
                x_bar_hat = [x1_nominal; x_o_hat];
                x_hat = T_inv * x_bar_hat;
            end
            
            % Ensure column vectors (NO CHAIN INDEXING!)
            x_hat_col = x_hat(:);
            r_col = results(test_idx).r(:,k);
            r_col = r_col(:);
            d_col = results(test_idx).d(:,k);
            d_col = d_col(:);
            
            % Control law
            u = -K * x_hat_col + N * r_col + d_col;
            results(test_idx).u(:,k,sc) = u;
            
            % Plant update
            dx = vehicle_dynamics(x, u, M, Iz, Lf, Lr, Lt, Kr, Ce, vxb_min);
            x = x + dt * dx;
        end
    end
end

%% ------------------------------------------------------------------------
% PERFORMANCE METRICS CALCULATION
%% ------------------------------------------------------------------------
fprintf('\nCalculating performance metrics...\n');
metrics = struct();

for test_idx = 1:3
    N_test = length(results(test_idx).t);
    metrics(test_idx).name = results(test_idx).name;
    
    for sc = 1:n_scenarios
        y = results(test_idx).y(:,:,sc);
        r_out = results(test_idx).r(1:3,:);  % Reference for outputs
        
        e_track = sqrt(sum((y - r_out).^2, 1));
        e_est = sqrt(sum((results(test_idx).x(:,:,sc) - results(test_idx).x_hat(:,:,sc)).^2, 1));
        u_effort = sqrt(sum(results(test_idx).u(:,:,sc).^2, 1));
        
        metrics(test_idx).scenario{sc} = scenarios{sc,1};
        metrics(test_idx).has_noise(sc) = scenarios{sc,2};
        metrics(test_idx).RMSE_track(sc) = sqrt(mean(e_track.^2));
        metrics(test_idx).RMSE_est(sc) = sqrt(mean(e_est.^2));
        metrics(test_idx).RMSE_u(sc) = sqrt(mean(u_effort.^2));
        
        ss_start = round(0.8*N_test);
        metrics(test_idx).ss_error(sc) = mean(e_track(ss_start:end));
    end
end

%% ------------------------------------------------------------------------
% PLOTTING ALL RESULTS (ONLY 3 TESTS)
%% ------------------------------------------------------------------------
colors = lines(n_scenarios);
line_styles = {'-', '-', '--', '-', '--'};

for test_idx = 1:3
    t_test = results(test_idx).t;
    N_test = length(t_test);
    
    % --- FIGURE 1: OUTPUT TRACKING ---
    figure('Name',sprintf('TEST %d: Output Tracking', test_idx),'NumberTitle','off','Position',[100,100,1200,800]);
    subplot(3,1,1);
    for sc = 1:n_scenarios
        plot(t_test, results(test_idx).y(1,:,sc), 'Color', colors(sc,:), 'LineStyle', line_styles{sc}, 'LineWidth', 1.2); hold on;
    end
    plot(t_test, results(test_idx).r(1,:), 'k:', 'LineWidth', 2);
    grid on; ylabel('v_{xb} (m/s)'); title(sprintf('TEST %d: %s', test_idx, results(test_idx).name));
    
    subplot(3,1,2);
    for sc = 1:n_scenarios
        plot(t_test, results(test_idx).y(2,:,sc), 'Color', colors(sc,:), 'LineStyle', line_styles{sc}, 'LineWidth', 1.2); hold on;
    end
    plot(t_test, results(test_idx).r(2,:), 'k:', 'LineWidth', 2);
    grid on; ylabel('v_{yb} (m/s)');
    
    subplot(3,1,3);
    for sc = 1:n_scenarios
        plot(t_test, results(test_idx).y(3,:,sc), 'Color', colors(sc,:), 'LineStyle', line_styles{sc}, 'LineWidth', 1.2); hold on;
    end
    plot(t_test, results(test_idx).r(3,:), 'k:', 'LineWidth', 2);
    grid on; ylabel('\omega (rad/s)'); xlabel('Time (s)');
    
    legend_entries = {};
    for sc = 1:n_scenarios
        noise_str = results(test_idx).has_noise(sc) * ' (noisy)' + ~results(test_idx).has_noise(sc) * ' (clean)';
        legend_entries{end+1} = sprintf('%s%s', results(test_idx).scenario{sc}, noise_str);
    end
    legend_entries{end+1} = 'Reference';
    legend(legend_entries, 'Location', 'best');
end

%% ------------------------------------------------------------------------
% METRICS SUMMARY TABLE
%% ------------------------------------------------------------------------
fprintf('\n=== PERFORMANCE METRICS SUMMARY ===\n');
fprintf('Test\tScenario          \tNoise\tRMSE_track\tRMSE_est\tSS_Error\tRMSE_u\n');
fprintf('----\t------------------\t-----\t----------\t---------\t---------\t------\n');

for test_idx = 1:3
    for sc = 1:n_scenarios
        noise_str = metrics(test_idx).has_noise(sc) * 'Y' + ~metrics(test_idx).has_noise(sc) * 'N';
        fprintf('%d\t%-18s\t%s\t%8.4f\t%8.4f\t%8.4f\t%6.2f\n', ...
            test_idx, ...
            metrics(test_idx).scenario{sc}, ...
            noise_str, ...
            metrics(test_idx).RMSE_track(sc), ...
            metrics(test_idx).RMSE_est(sc), ...
            metrics(test_idx).ss_error(sc), ...
            metrics(test_idx).RMSE_u(sc));
    end
    fprintf('----\t------------------\t-----\t----------\t---------\t---------\t------\n');
end