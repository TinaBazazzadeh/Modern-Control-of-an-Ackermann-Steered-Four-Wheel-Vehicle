%% FINAL Nonlinear Simulation - Robustness Analysis (Task 11)
% Based on user request and Nonlin10.m structure
clear; clc; close all;

% ------------------------------------------------------------------
% 1. INITIALIZATION & NOMINAL DESIGN
% ------------------------------------------------------------------
% Nominal System Matrices
A_nom = [-0.0022, 0, 0, 0;
          0, -13.8828, 0, -1.1393;
          0, 0, 0, 1;
          0, 1.5933, 0, -13.1524];

B_nom = [0, 0.0006, 0.0006, 0.0006, 0.0006;
         30.5862, 0, 0, 0, 0;
         0, 0, 0, 0, 0;
         17.6719, -0.0002, -0.0002, 0.0002, 0.0002];

C_mat = [1, 0, 0, 0; 0, 1, 0, 0; 0, 0, 0, 1]; 

% Controller Design (Nominal)
Kbar = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1; 1 2 3 4];
F_pol = [-15,-1,0,0; 1,-15,0,0; 0,0,-20,0; 0,0,0,-10];
P = sylvester(A_nom, -F_pol, B_nom*Kbar);
K = Kbar * inv(P);
G0 = -C_mat * ((A_nom - B_nom*K) \ B_nom);
N = pinv(G0);

% Observer Design (Nominal)
[Abar, ~, Cbar, T, ~] = obsvf(A_nom, B_nom, C_mat);
Ao = Abar(2:4, 2:4);
Co = Cbar(:, 2:4);
L_full = place(Ao', Co', -45*ones(1,3))';
obs_idx = 2:4; unobs_idx = 1;

% Nominal Physical Parameters
M = 1500; Iz = 2500; Lf = 1.2; Lr = 1.6; Lt = Lf + Lr;
Kf_nom = 80000; Kr_nom = 90000; Ce = 10;
ode_opts = odeset('RelTol', 1e-3, 'AbsTol', 1e-4, 'MaxStep', 0.02);

% ------------------------------------------------------------------
% 2. ROBUSTNESS LOOP SETUP
% ------------------------------------------------------------------
uncertainties = -0.30:0.05:0.30; % -30% to +30%
n_tests = length(uncertainties);
rmse_standard = zeros(1, n_tests);
rmse_improved = zeros(1, n_tests);
stability_flags = zeros(1, n_tests); % 1=Stable, 0=Unstable

% Simulation Settings
tspan = 0:0.02:10;
x0 = [0.2; 0.1; 0; 0.05]; % Non-zero IC to test estimation convergence
r_func = @(t) [1; 0; 0];  % Step reference
d_func = @(t) zeros(5,1);

fprintf('Running Robustness Analysis...\n');

for i = 1:n_tests
    unc_factor = 1 + uncertainties(i);
    
    % --- Apply Uncertainty to PHYSICAL PLANT ---
    % Since A depends linearly on Kf/Kr in the bicycle model, 
    % we scale stiffness to represent matrix A scaling.
    Kf_pert = Kf_nom * unc_factor;
    Kr_pert = Kr_nom * unc_factor;
    
    % --- Standard Observer Simulation ---
    [~, x_true, x_est_std] = simulate_robust(tspan, x0, r_func, d_func, ...
        K, N, M, Iz, Lf, Lr, Lt, Kf_pert, Kr_pert, Ce, ode_opts, ...
        T, unobs_idx, obs_idx, L_full, Co, Ao, C_mat, ...
        false); % false = No Improvement
    
    % --- Improved Observer Simulation (Integral Correction) ---
    [~, ~, x_est_imp] = simulate_robust(tspan, x0, r_func, d_func, ...
        K, N, M, Iz, Lf, Lr, Lt, Kf_pert, Kr_pert, Ce, ode_opts, ...
        T, unobs_idx, obs_idx, L_full, Co, Ao, C_mat, ...
        true);  % true = With Improvement
    
    % Calculate RMSE for Vy (State 2) and Omega (State 4) - Observable states
    err_std = x_true([2,4], :) - x_est_std([2,4], :);
    err_imp = x_true([2,4], :) - x_est_imp([2,4], :);
    
    rmse_standard(i) = sqrt(mean(mean(err_std.^2)));
    rmse_improved(i) = sqrt(mean(mean(err_imp.^2)));
    
    % Simple stability check (divergence check)
    if max(abs(x_true(:))) < 100
        stability_flags(i) = 1;
    else
        stability_flags(i) = 0; 
    end
end

% ------------------------------------------------------------------
% 3. PLOTTING RESULTS
% ------------------------------------------------------------------
figure('Name', 'Robustness Analysis', 'Color', 'w');

% Plot 1: RMSE vs Uncertainty
subplot(2,1,1);
plot(uncertainties*100, rmse_standard, 'r-o', 'LineWidth', 2, 'MarkerFaceColor', 'r'); hold on;
plot(uncertainties*100, rmse_improved, 'b-s', 'LineWidth', 2, 'MarkerFaceColor', 'b');
grid on;
xlabel('Uncertainty in Plant Dynamics (%)');
ylabel('Estimation RMSE');
title('Observer Robustness: Standard vs. Improved (Integral Correction)');
legend('Standard Observer (Nominal)', 'Improved Observer (Integral Comp.)');

% Plot 2: Closed-Loop Performance Metric (Steady State Error) for selected points
subplot(2,1,2);
bar(uncertainties*100, [rmse_standard' rmse_improved']);
grid on;
xlabel('Uncertainty (%)');
ylabel('RMSE Magnitude');
title('Comparative Error Analysis');
legend('Standard', 'Improved');

fprintf('\nAnalysis Complete.\n');
fprintf('Proposed Method: Output Integral Injection (reduces steady-state error caused by model mismatch).\n');

% ------------------------------------------------------------------
% HELPER FUNCTIONS
% ------------------------------------------------------------------
function [t_out, x_true, x_hat] = simulate_robust(tspan, x0, r_func, d_func, ...
    K, N, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce, ode_opts, ...
    T, unobs_idx, obs_idx, L_full, Co, Ao, C_mat, use_improvement)

    dt = tspan(2) - tspan(1);
    n = length(tspan);
    
    x_true = zeros(4,n); x_true(:,1) = x0;
    x_hat = zeros(4,n);  x_hat(:,1) = x0;
    
    % Observer internal state (Transformed coords)
    z_hat = zeros(4,n);
    z_hat(:,1) = T * x0;
    
    % Integral Error State for Proposed Method
    int_error = zeros(3,1); 
    K_int = 5 * eye(3); % Tune integral gain here
    
    for k = 2:n
        t_curr = tspan(k);
        x_prev = x_true(:,k-1);
        z_prev = z_hat(obs_idx, k-1);
        
        % Controller uses Estimated State
        u = -K * x_hat(:,k-1) + N * r_func(t_curr) + d_func(t_curr);
        
        % TRUE SYSTEM PROPAGATION (Using Perturbed Parameters Kf, Kr)
        odefun = @(t,x) vehicle_ode_pert(t, x, u, M, Iz, Lf, Lr, Lt, Kf, Kr, Ce);
        [~, xsol] = ode45(odefun, [0 dt], x_prev, ode_opts);
        x_true(:,k) = xsol(end,:)';
        
        % Measurement
        y_meas = C_mat * x_true(:,k);
        
        % OBSERVER UPDATE (Using Nominal Ao, Co, L_full)
        y_est = Co * z_prev;
        meas_residue = y_meas - y_est;
        
        % Standard Observer Dynamics
        dz_obs = Ao * z_prev + L_full * meas_residue;
        
        if use_improvement
            % PROPOSED METHOD: Add Integral of Estimation Error
            % Corrects the derivative using past accumulated error
            int_error = int_error + meas_residue * dt;
            dz_obs = dz_obs + K_int * int_error; 
        end
        
        % Euler integration for observer
        z_next = z_prev + dt * dz_obs;
        
        % Store
        z_hat(:,k) = z_hat(:,k-1); % Copy unobservable
        z_hat(obs_idx, k) = z_next;
        x_hat(:,k) = T' * z_hat(:,k);
    end
    t_out = tspan;
end

function dx = vehicle_ode_pert(~, x, u, M, Iz, Lf, Lr, Lt, Kr, Kf, Ce)
    % Nonlinear Dynamics with VARIABLE Kf, Kr
    vxb = x(1); vyb = x(2); w = x(4);
    
    % Forces mapping
    Fy_front_total = u(1);
    Fx_total = sum(u(2:5));
    
    % Safe velocity
    if abs(vxb) < 0.5, vxb_safe = 0.5 * sign(vxb + (vxb==0)); else, vxb_safe = vxb; end
    
    % Linear tire model within Nonlinear dynamics
    alfa_r = -(vyb - Lr*w) / vxb_safe;
    alfa_f = -(vyb + Lf*w) / vxb_safe + Fy_front_total/Kf; % Simplified steering approx
    
    % Recalculate forces based on PERTURBED Stiffness
    % Note: In the original code, Fy inputs were direct. 
    % Here we assume the plant reacts with its own Kf/Kr
    % For consistent simulation with original:
    Fy_r = Kr * alfa_r;
    
    % To keep consistent with input u(1) which is Fy_f, we assume u(1) acts directly
    % but lateral dynamics depend on the plant's parameters.
    % Let's use the standard equations:
    Fy_f = u(1); % Input is force
    Fy_r = Kr * alfa_r; % Rear is reactive
    
    vxb_dot = w*vyb + (Fx_total - Ce*vxb^2)/M;
    vyb_dot = -w*vxb + (Fy_f + Fy_r)/M;
    theta_dot = w;
    w_dot = (Lf*Fy_f - Lr*Fy_r)/Iz;
    
    dx = [vxb_dot; vyb_dot; theta_dot; w_dot];
end