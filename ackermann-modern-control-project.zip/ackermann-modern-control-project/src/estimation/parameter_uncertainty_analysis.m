%% Initial Setup: Define System and Previous Designs
clc; clear; close all;

% 1. System Definition (From Source 1 & 2)
A = [-0.0022,0,0,0; 0,-13.8828,0,-1.1393; 0,0,0,1; 0,1.5933,0,-13.1524]; 
B = [0,0.0006,0.0006,0.0006,0.0006; 30.5862,0,0,0,0; 0,0,0,0,0; 17.6719,-0.0002,-0.0002,0.0002,0.0002]; 
C = [1,0,0,0; 0,1,0,0; 0,0,0,1]; 
D = zeros(3,5);

% 2. Observer Design (Replicating Phase 10)
% Decomposition to handle unobservable state
[Abar, Bbar, Cbar, T, k] = obsvf(A, B, C);
Ao = Abar(2:4,2:4); % Observable Subsystem A (3x3)
Bo = Bbar(2:4, :); % Observable Subsystem B
Co = Cbar(1:3,2:4); % Observable Subsystem C

% Nominal Observer Gain (Fixed L from previous phase)
observer_poles = -30 * ones(1, 3);
L = place(Ao', Co', observer_poles)'; 

% 3. Controller Design (Replicating Phase 8/9)
% Using Sylvester Equation for Pole Placement
F = [-15,-1,0,0; 1,-15,0,0; 0,0,-20,0; 0,0,0,-10]; % Desired Poles
Kbar = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1; 1 2 3 4]; 
RHS = B * Kbar;          
P = sylvester(A, -F, RHS);   
K = Kbar * inv(P); % Controller Gain (Full State Feedback)

% Prefilter N calculation
Acl_nom = A - B*K;
G0 = -C * (Acl_nom \ B);
N = pinv(G0); % Static Prefilter

%% PART 1: Estimation in Presence of Uncertainty
% Range: -30% to +30% with 5% step
uncertainties = -0.30 : 0.05 : 0.30; 
RMSE_history = zeros(length(uncertainties), 1);
SSE_history = zeros(length(uncertainties), 1); % Steady State Error

% Simulation Parameters
t = 0:0.001:5;
dt = t(2)-t(1);
nSamples = length(t);
x0_true = [0.5; -0.2; 0.0873; 0]; % True initial state
z0_obs = [0; 0; 0]; % Observer initial state (transformed domain)
u_input = 1 * ones(5, nSamples); % Step input for all channels

fprintf('Running Uncertainty Analysis on Estimation...\n');

for i = 1:length(uncertainties)
    alpha = 1 + uncertainties(i);
    A_pert = alpha * A; % The "Real" Plant changes
    
    % Storage
    x_true = zeros(4,nSamples); x_true(:,1) = x0_true;
    z_est = zeros(3,nSamples); z_est(:,1) = z0_obs; % Estimating observable states
    
    for k = 2:nSamples
        % 1. Real System (Perturbed)
        dx_true = A_pert * x_true(:,k-1) + B * u_input(:,k-1);
        x_true(:,k) = x_true(:,k-1) + dt * dx_true;
        
        y = C * x_true(:,k-1); 
        
        % 2. Observer (Based on Nominal Ao, Bo, Co and FIXED L)
        % Note: Observer works in the Transformed (Observable) domain
        y_est = Co * z_est(:,k-1);
        dz_est = Ao * z_est(:,k-1) + Bo * u_input(:,k-1) + L * (y - y_est);
        z_est(:,k) = z_est(:,k-1) + dt * dz_est;
    end
    
    % Convert True states to Observable Domain for comparison
    x_true_bar = T * x_true; 
    z_true_obs = x_true_bar(2:4, :); % Extract observable part
    
    error = z_true_obs - z_est;
    RMSE_history(i) = sqrt(mean(mean(error.^2)));
    % Steady State Error (Last 10% of data)
    SSE_history(i) = mean(sqrt(sum(error(:,end-round(0.1*nSamples):end).^2, 1))); 
end

% Plotting Error vs Uncertainty
figure;
subplot(2,1,1);
plot(uncertainties*100, RMSE_history, '-o', 'LineWidth', 2);
title('Impact of Parameter Uncertainty on Estimation (RMSE)');
xlabel('Uncertainty in A (%)'); ylabel('RMSE'); grid on;

subplot(2,1,2);
plot(uncertainties*100, SSE_history, '-s', 'LineWidth', 2, 'Color', 'r');
title('Steady-State Estimation Error vs Uncertainty');
xlabel('Uncertainty in A (%)'); ylabel('Steady-State Error'); grid on;

%% PART 2: Proposed Improvement (Integral of Residuals)
% Strategy: Add an integral term to the observer structure.
% \dot{\hat{x}} = A\hat{x} + Bu + L(y-\hat{y}) + Ki * \int(y-\hat{y})dt
% This removes bias caused by model mismatch without changing L.

Ki_obs = 80 * eye(3); % Integral Gain for the Observer
RMSE_imp_hist = zeros(length(uncertainties), 1);
SSE_imp_hist = zeros(length(uncertainties), 1);

fprintf('Running Improved Observer Simulation...\n');

for i = 1:length(uncertainties)
    alpha = 1 + uncertainties(i);
    A_pert = alpha * A; 
    
    x_true = zeros(4,nSamples); x_true(:,1) = x0_true;
    z_est = zeros(3,nSamples); z_est(:,1) = z0_obs;
    int_residue = zeros(3,1); % Integral accumulator
    
    for k = 2:nSamples
        % Real System
        x_true(:,k) = x_true(:,k-1) + dt * (A_pert * x_true(:,k-1) + B * u_input(:,k-1));
        y = C * x_true(:,k-1);
        
        % Improved Observer
        y_est = Co * z_est(:,k-1);
        residue = y - y_est;
        
        % Integral Action Update
        int_residue = int_residue + residue * dt;
        
        % Observer Dynamics with Integral Injection
        correction = L * residue + Ki_obs * int_residue; 
        dz_est = Ao * z_est(:,k-1) + Bo * u_input(:,k-1) + correction;
        z_est(:,k) = z_est(:,k-1) + dt * dz_est;
    end
    
    x_true_bar = T * x_true; 
    z_true_obs = x_true_bar(2:4, :);
    
    error = z_true_obs - z_est;
    RMSE_imp_hist(i) = sqrt(mean(mean(error.^2)));
    SSE_imp_hist(i) = mean(sqrt(sum(error(:,end-round(0.1*nSamples):end).^2, 1)));
end

% Comparison Plot
figure;
plot(uncertainties*100, SSE_history, 'r--o', 'LineWidth', 1.5); hold on;
plot(uncertainties*100, SSE_imp_hist, 'b-s', 'LineWidth', 1.5);
legend('Standard Observer (Fixed L)', 'Proposed PI-Observer (Integral Action)');
title('Improvement in Steady-State Estimation Error');
xlabel('Uncertainty in A (%)'); ylabel('Steady State Error'); grid on;

%% PART 3: Closed-Loop Performance Analysis
% Analyzing the Controller designed in Part 8/9 applied to the Uncertain System

fprintf('Running Closed-Loop Analysis...\n');
results_table = [];
ref = [1; 1; 1]; % Reference for outputs

for i = 1:length(uncertainties)
    alpha = 1 + uncertainties(i);
    A_pert = alpha * A;
    
    x_sys = zeros(4,nSamples); 
    % We assume full state feedback is available for this analysis 
    % (or reconstructed ideally) to isolate controller robustness
    
    for k = 2:nSamples
        % Control Law: u = -K * x + N * r
        u_val = -K * x_sys(:,k-1) + N * ref; 
        
        % True System Dynamics (Perturbed)
        dx_sys = A_pert * x_sys(:,k-1) + B * u_val;
        x_sys(:,k) = x_sys(:,k-1) + dt * dx_sys;
    end
    
    y_out = C * x_sys;
    
    % Analyze Step Response (using 1st output channel)
    output_sig = y_out(1,:); 
    
    % Calculate Metrics manually or via stepinfo
    final_val = mean(output_sig(end-100:end));
    ess = abs(ref(1) - final_val);
    
    % Simple Stability Check (Bounded output)
    if any(abs(output_sig) > 1e4) || isnan(final_val)
        stable = 0; S_os=NaN; S_ts=NaN; 
    else
        stable = 1;
        % Calculate Overshoot %
        [max_val, ~] = max(output_sig);
        if max_val > final_val
            S_os = (max_val - final_val)/final_val * 100;
        else
            S_os = 0;
        end
        % Approximate Settling Time (2%)
        abs_err = abs(output_sig - final_val);
        idx = find(abs_err > 0.02*final_val, 1, 'last');
        if isempty(idx), S_ts = 0; else, S_ts = t(idx); end
    end
    
    % Store: [Uncertainty%, Stable, Overshoot, SettlingTime, SteadyStateError]
    results_table = [results_table; uncertainties(i)*100, stable, S_os, S_ts, ess];
end

% Display Results Table
fprintf('\n--- Closed Loop Controller Performance under Uncertainty ---\n');
fprintf('%8s %8s %10s %10s %10s\n', 'Uncert(%)', 'Stable', 'OS(%)', 'Ts(s)', 'Ess');
disp(results_table);

% Plot Closed Loop Metrics
figure;
subplot(2,2,1); 
plot(results_table(:,1), results_table(:,3), 'r-o'); 
title('Overshoot vs Uncertainty'); ylabel('%'); grid on;

subplot(2,2,2); 
plot(results_table(:,1), results_table(:,4), 'b-s'); 
title('Settling Time vs Uncertainty'); ylabel('Time (s)'); grid on;

subplot(2,2,[3 4]); 
plot(results_table(:,1), results_table(:,5), 'k-d', 'LineWidth', 1.5); 
title('Tracking Error (Ess) vs Uncertainty'); 
xlabel('Uncertainty (%)'); ylabel('Error Magnitude'); grid on;