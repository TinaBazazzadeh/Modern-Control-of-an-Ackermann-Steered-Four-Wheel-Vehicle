% for internal stability
A = [0 0 0 0; 0 -21.3333 0 -0.7333; 0 0 0 1; 0 2.8444 0 -28.4444];
eig(A)

% for BIBO stability
A = [0 0 0 0; 0 -21.3333 0 -0.7333; 0 0 0 1; 0 2.8444 0 -28.4444];
B = [0; 53.3333; 0; 42.6667];
C = [1 0 0 0; 0 1 0 0; 0 0 0 1];
D = [0; 0; 0];
sys = ss(A,B,C,D);
G = tf(sys)

% for lyapanouv stability
A = [0 0 0 0; 0 -21.3333 0 -0.7333; 0 0 0 1; 0 2.8444 0 -28.4444];
Q = eye(size(A));
P = lyap(A', Q)

% for step response
A = [0 0 0 0; 0 -21.3333 0 -0.7333; 0 0 0 1; 0 2.8444 0 -28.4444];
B = [0; 53.3333; 0; 42.6667];
C = [1 0 0 0; 0 1 0 0; 0 0 0 1];
D = [0; 0; 0];
sys = ss(A,B,C,D);
G = tf(sys);
[num, den] = tfdata(G, 'v');
t = 0:0.01:10;    
figure; step(sys, t); title('Step response (step)'); grid on;