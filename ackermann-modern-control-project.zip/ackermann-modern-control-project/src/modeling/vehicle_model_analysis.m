%% ===============================================================
%  VEHICLE DYNAMICS – Nonlinear vs Linear + Eigen/Jordan/TF/PZ
%  States: [vx; vy; theta; w]
%  Input : delta (steering)
%  Outputs (linear model): [vx; vy; w]
% ===============================================================

clear; clc; close all;

%% Parameters
m   = 1500;      
Iz  = 2250;      
Lf  = 1.2;       
Lr  = 1.6;       
Cf  = 80000;     
Cr  = 80000;     

Vx0    = 5;                % equilibrium vx
Vy0    = 0;                % equilibrium vy
w0     = 0;                % equilibrium yaw rate
theta0 = deg2rad(45);      % equilibrium heading

%% Symbolic Linearization (Jacobian) around equilibrium
syms vx vy th w delta real 

alpha_f = delta - atan((vy + Lf*w)/vx);
alpha_r = - atan((vy - Lr*w)/vx);

Fy_f = Cf * alpha_f;
Fy_r = Cr * alpha_r;

f1 = vy*w;
f2 = -vx*w + (Fy_f + Fy_r)/m;
f3 = w;
f4 = (Lf*Fy_f - Lr*Fy_r)/Iz;

f  = [f1; f2; f3; f4];
xv = [vx; vy; th; w];

A_sym = jacobian(f,xv);
B_sym = jacobian(f,delta);

A = double(subs(A_sym, {vx,vy,w,delta}, {Vx0,0,0,0}));
B = double(subs(B_sym, {vx,vy,w,delta}, {Vx0,0,0,0}));

% Outputs: y = [vx; vy; w]
C = [1 0 0 0;
     0 1 0 0;
     0 0 0 1];

D = zeros(3,1);

disp(' State-Space Matrices (Linearized) ');
disp('A ='); disp(A);
disp('B ='); disp(B);
disp('C ='); disp(C);
disp('D ='); disp(D);

%% Eigenvalues / Eigenvectors / Jordan Form
[V_eig, D_eig] = eig(A);      % eigenvectors & eigenvalues
eig_values = diag(D_eig);

disp('Eigenvalues ');
disp(eig_values);
disp('Eigenvectors (columns of V_eig)');
disp(V_eig);

% Jordan form (symbolic to get exact structure)
A_sym_num = sym(A);
[J_sym, P_sym] = jordan(A_sym_num);

J = double(J_sym);
P = double(P_sym);

disp(' Jordan Form J ');
disp(J);
disp(' Similarity Matrix P (A = P*J*inv(P))');
disp(P);
%% State Transition Matrix:
syms t
phi = expm(A * t);
disp ('State transition matrix :');
phi

%% Transfer functions (each output w.r.t steering input delta)
sys = ss(A,B,C,D);
G = tf(sys);      % 3x1 transfer function matrix

G_vx = G(1);      % TF from delta to vx
G_vy = G(2);      % TF from delta to vy
G_w  = G(3);      % TF from delta to w

disp(' Transfer Functions ');
disp('G_vx(s) = vx(s) / delta(s):');
G_vx
disp('G_vy(s) = vy(s) / delta(s):');
G_vy
disp('G_w(s)  = w(s)  / delta(s):');
G_w

%% Pole-zero plots for each transfer function 
figure;
subplot(3,1,1);
pzmap(G_vx); grid on;
title('G_{vx}(s)');

subplot(3,1,2);
pzmap(G_vy); grid on;
title('G_{vy}(s)');

subplot(3,1,3);
pzmap(G_w); grid on;
title('G_{w}(s)');

%% Input (steering) for simulation
u_input = @(t) 5*pi/180;    % 5 deg step

%% Initial state (nonlinear & linear)
x0 = [Vx0; Vy0; theta0; w0];

%% Nonlinear simulation
fNL = @(t,x) vehicle_nonlinear_local(x, u_input(t), m,Iz,Cf,Cr,Lf,Lr);

tspan = [0 3];
[tNL, xNL] = ode45(fNL, tspan, x0);

%% Linear simulation (around equilibrium point)
z0 = x0 - [Vx0; Vy0; theta0; w0];      % deviation from equilibrium

[tL, zL] = ode45(@(t,z) A*z + B*u_input(t), tspan, z0);
xL = zL + [Vx0 Vy0 theta0 w0];         % reconstruct states

%% Extract outputs from both models
vx_NL = xNL(:,1);   vy_NL = xNL(:,2);   w_NL  = xNL(:,4);
vx_L  = xL(:,1);    vy_L  = xL(:,2);    w_L   = xL(:,4);

%% Plot comparison: vx, vy, w
figure;

subplot(3,1,1)
plot(tNL, vx_NL, 'b', 'LineWidth', 2); hold on;
plot(tL,  vx_L,  'r--', 'LineWidth', 2);
grid on; xlabel('Time (s)'); ylabel('v_x');
title('Nonlinear vs Linear – v_x'); 
legend('Nonlinear','Linear');

subplot(3,1,2)
plot(tNL, vy_NL, 'b', 'LineWidth', 2); hold on;
plot(tL,  vy_L,  'r--', 'LineWidth', 2);
grid on; xlabel('Time (s)'); ylabel('v_y');
title('Nonlinear vs Linear – v_y'); 
legend('Nonlinear','Linear');

subplot(3,1,3)
plot(tNL, w_NL, 'b', 'LineWidth', 2); hold on;
plot(tL,  w_L,  'r--', 'LineWidth', 2);
grid on; xlabel('Time (s)'); ylabel('w');
title('Nonlinear vs Linear – yaw rate w'); 
legend('Nonlinear','Linear');

%% Zero input Response:
t = 0:0.01:10;
X0= [100;3;3;1];
figure;
subplot(3,1,1); initial(sys, x0); title('Zero Input Response')
subplot(3,1,2); step(sys);       title('Step Response')
subplot(3,1,3); impulse(sys);    title('Impulse Response')  

%% LOCAL FUNCTION: Nonlinear Vehicle Model
function dx = vehicle_nonlinear_local(x,u,m,Iz,Cf,Cr,Lf,Lr)

vx = x(1);
vy = x(2);
theta = x(3); 
w  = x(4);

delta = u;

% Slip angles
alpha_f = delta - atan((vy + Lf*w)/vx);
alpha_r = - atan((vy - Lr*w)/vx);

% Tire forces
Fy_f = Cf * alpha_f;
Fy_r = Cr * alpha_r;

dx = zeros(4,1);

dx(1) = vy*w;                                % longitudinal coupling
dx(2) = -vx*w + (Fy_f + Fy_r)/m;             % lateral dynamics
dx(3) = w;                                   % heading angle
dx(4) = (Lf*Fy_f - Lr*Fy_r)/Iz;              % yaw dynamics

%% Calculating the Ctrb & Obsv Matrices and their ranks
A = [0,0,0,0;0,-21.3333,0,-0.7333;0,0,0,1;0,2.8444,0,-28.4444];
B = [0;53.3333;0;42.6667];
C = [1,0,0,0;0,1,0,0;0,0,0,1];
D = [0;0;0];
Controllability = ctrb(A,B)
Observability = obsv(A,C)
rank(Controllability)
rank(Observability)
%% Controllability Decomposition
[Abar,Bbar,Cbar,T,K]=ctrbf(A,B,C)
Ac = Abar(2:4,2:4)
Bc = Bbar(2:4)
Cc = Cbar(1:3,2:4)
Auc = Abar(1,1)
Buc = Bbar(1,1)
Cuc = Cbar(1:3,1)
eig(Ac)
eig(Auc)
N = ctrb(Ac,Bc)
rank(N)
%% Observability Decomposition
[Abar,Bbar,Cbar,T,K]=obsvf(A,B,C)
Ao = Abar(2:4,2:4)
Bo = Bbar(2:4)
Co = Cbar(1:3,2:4)
Auo = Abar(1,1)
Buo = Bbar(1,1)
Cuo = Cbar(1:3,1)
eig(Ao)
eig(Auo)
N = obsv(Ao,Co)
rank(N)
%% Kalman Decomposition, Decomposing Controllable part to (Un)observable
[Abar,Bbar,Cbar,T,K]=obsvf(Ac,Bc,Cc)
Aco = Abar(2:3,2:3)
Bco = Bbar(2:3)
Cco = Cbar(1:3,2:3)
Acuo = Abar(1,1)
Bcuo = Bbar(1,1)
Ccuo = Cbar(1:3,1)
eig(Aco)
eig(Acuo)
N = obsv(Aco,Cco)
rank(N)
%% Kalman Decomposition, Decomposing Unontrollable part to (Un)observable
[Abar,Bbar,Cbar,T,K]=obsvf(Auc,Buc,Cuc)
obsv(Auc,Cuc)
rank(obsv(Auc,Cuc))
end
