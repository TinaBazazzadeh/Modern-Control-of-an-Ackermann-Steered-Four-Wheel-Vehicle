clc; 
clear; 
close all; 
%% Extracting the observable subsystem to design the observer
A = [-0.0022,0,0,0;0,-13.8828,0,-1.1393;0,0,0,1;0,1.5933,0,-13.1524]; 
B = [0,0.0006,0.0006,0.0006,0.0006;30.5862,0,0,0,0;0,0,0,0,0;17.6719,-0.0002,-0.0002,0.0002,0.0002]; 
C = [1,0,0,0;0,1,0,0;0,0,0,1]; 
D = [0,0,0,0,0;0,0,0,0,0;0,0,0,0,0]; 
O = obsv(A,C);
rank(O);
[Abar,Bbar,Cbar,T,k] = obsvf(A,B,C)
Ao = Abar(2:4,2:4)
Bo = Bbar(2:4, :)
Co = Cbar(1:3,2:4)
% Auo = Abar(1,1)
% Buo = Bbar(1, :)
% Cuo = Cbar(:, 1)
obsv(Ao,Co)
rank(obsv(Ao,Co)) 
eig(Ao)
rank(Co)
%% Placing the desired observer poles and designing a full_order observer
observer_poles = -30 * ones(1, 3);  
L = place(Ao', Co', observer_poles)';
L
disp(L);
eig(Ao - L*Co)
%% reduced_order observer (n-q) n = 3 q = 3

n = size(Ao, 1)      
q = rank(Co)  % zero order observer
Q1 = inv(Co)
% y = Co * x;          
% x_hat = Q1 * y;        

%% Simulation‌
t = 0:0.001:5;          
dt = t(2)-t(1);
N = length(t);

x0_true = [0.5; -0.2; 0.0873];  
x0_obs = [0; 0; 0];      

x_true = zeros(3,N); x_true(:,1) = x0_true;
x_full = zeros(3,N); x_full(:,1) = x0_obs;
x_red  = zeros(3,N); x_red(:,1)  = Q1 * (Co * x0_true);

for k = 2:N
  
    x_true(:,k) = x_true(:,k-1) + dt * (Ao * x_true(:,k-1));
   
    y = Co * x_true(:,k);
   
    x_full(:,k) = x_full(:,k-1) + dt * (Ao*x_full(:,k-1) + L*(y - Co*x_full(:,k-1)));
    
    x_red(:,k) = Q1 * y;
end

e_full = x_true - x_full;
e_red  = x_true - x_red;
%% RMSE Calculations

RMSE_full = sqrt(mean(sum(e_full.^2, 1)));
RMSE_red  = sqrt(mean(sum(e_red.^2, 1)));

%% Steady-state error (average of last 10%)

window = round(0.1*N);
e_full_ss = mean(sqrt(sum((x_true(:,end-window+1:end) - x_full(:,end-window+1:end)).^2, 1)));
e_red_ss  = mean(sqrt(sum((x_true(:,end-window+1:end) - x_red(:,end-window+1:end)).^2, 1)));

%% Convergence time (time to reach 5% of initial error)

e0_full = norm(x_true(:,1) - x_full(:,1));
threshold = 0.05 * e0_full;
e_inst_full = sqrt(sum((x_true - x_full).^2, 1));
idx_conv = find(e_inst_full < threshold, 1, 'first');
if isempty(idx_conv)
    t_conv = NaN;  
else
    t_conv = t(idx_conv);
end

%% Results 
fprintf('      1. RMSE:\n');
fprintf(' Full order observer:   RMSE = %.4f\n', RMSE_full);
fprintf(' Reduced (Zero) order observer:       RMSE = %.2e\n', RMSE_red);
figure; plot(t, sqrt(sum(e_full.^2,1)),'r', t, sqrt(sum(e_red.^2,1)),'g--'); 
title(['RMSE Results']);
legend('Full order','Zero order'); grid on;

fprintf('      2. Steady-state error (average of last 10%%):\n');
fprintf(' Full order observer:    %.8f\n', e_full_ss);
fprintf(' Reduced order observer: %.8e\n', e_red_ss);

fprintf('      3. Convergence time (to 5%% of initial error):\n');
if isnan(t_conv)
    fprintf(' Full-order observer:    Did not converge within 5 seconds\n');
else
    fprintf(' Full-order observer:    %.8f seconds\n', t_conv);
end
fprintf(' Reduced-order observer: 0.00000000 seconds (instantaneous estimation)\n');

%% Comparison with two levels of noise
sigma_levels = [0.005, 0.05]; 
labels = {'Low Noise', 'Medium Noise'};

figure;
for i = 1:2
    sigma = sigma_levels(i);
    x_full_n = zeros(3,N); x_full_n(:,1) = x0_obs;
    x_red_n  = zeros(3,N); x_red_n(:,1)  = Q1 * (Co * x0_true);

    for k = 2:N
        
        x_true_n = x_true(:,k); 
        y_noisy = Co * x_true_n + sigma * randn(3,1);
        x_full_n(:,k) = x_full_n(:,k-1) + dt * (Ao*x_full_n(:,k-1) + L*(y_noisy - Co*x_full_n(:,k-1)));
        x_red_n(:,k)  = Q1 * y_noisy;
    end
   
    e_full_n = x_true - x_full_n;
    e_red_n  = x_true - x_red_n;
    rmse_f = sqrt(mean(sum(e_full_n.^2, 1)));
    rmse_r = sqrt(mean(sum(e_red_n.^2, 1)));
    
    subplot(2,1,i);
    plot(t, sqrt(sum(e_full_n.^2,1)), 'r'); hold on;
    plot(t, sqrt(sum(e_red_n.^2,1)), 'b--');
    title(['Comparison at ', labels{i}, ' (\sigma = ', num2str(sigma), ')']);
    ylabel('Estimation Error'); grid on;
    legend(['Full Order (RMSE:', num2str(rmse_f,'%.4f'), ')'], ...
           ['Zero Order (RMSE:', num2str(rmse_r,'%.4f'), ')']);
end
xlabel('Time (s)');